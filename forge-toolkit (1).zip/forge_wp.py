#!/usr/bin/env python3
"""FORGE WordPress connector — REST client over Application Passwords, plus the media pipeline.
Env: WP_URL (https://site.com), WP_USER, WP_APP_PASS (Application Password, spaces allowed). Optional: WP_INSECURE=1 for self-signed dev hosts.
Commands:
  status                                  bridge + site capabilities (falls back to core REST if the bridge is absent)
  media-find "query"                      search the media library (bridge, or core /wp/v2/media?search=)
  media-upload path --alt "…" [--title "…"] [--caption "…"] [--reuse] [--max 1600] [--webp]   optimise + upload, print JSON
  media-resolve blueprint.json media_map.json [--assets DIR] [--reuse] [--dry]   resolve every media slot (path / URL / library:query / library:ID) → media_map.json
  import bundle.json [--status draft|publish] [--media media_map.json]           create/update the page through the bridge (or core REST without Elementor data)
  template template.json                                                          add an Elementor saved template through the bridge
  settings [--revalidate-url U] [--secret S] [--cors https://a.com,https://b.com] [--lead-email E] [--indexnow-key K]
  verify URL                              fetch a live page: title, meta, canonical, H1s, JSON-LD types, image alts, form present
  indexnow URL [URL…]                     ping IndexNow through the bridge
  sitemap [--base https://site]           list every URL in the live XML sitemap(s)
  links-check blueprint.json [--base U]   every internal link must be in the live sitemap (or answer HEAD < 400); exits 2 otherwise
  bridge-zip [forge-bridge.php]           zip the bridge as an installable plugin (Plugins → Add New → Upload)
"""
import os, sys, json, re, io, base64, mimetypes, hashlib, time
import requests

WP = os.environ.get('WP_URL', '').rstrip('/'); USER = os.environ.get('WP_USER', ''); PASS = os.environ.get('WP_APP_PASS', '')
VERIFY = not os.environ.get('WP_INSECURE')
S = requests.Session(); S.headers['User-Agent'] = 'FORGE/1.0 (+WordPress connector)'
if USER and PASS: S.auth = (USER, PASS)

def die(m, code=1): print('ERROR:', m, file=sys.stderr); sys.exit(code)
def api(path): return f"{WP}/wp-json/{path.lstrip('/')}"
def req(method, path, **kw):
    kw.setdefault('timeout', 60); kw.setdefault('verify', VERIFY)
    r = S.request(method, api(path), **kw)
    if r.status_code >= 400:
        try: j = r.json(); msg = j.get('message') or j
        except Exception: msg = r.text[:300]
        raise RuntimeError(f'{method} {path} → {r.status_code}: {msg}')
    return r.json() if r.content else {}
def has_bridge():
    try: req('GET', 'forge/v1/status'); return True
    except RuntimeError as e:
        if '404' in str(e) or 'rest_no_route' in str(e): return False
        raise

# ---------- status ----------
def status():
    if not WP: die('WP_URL not set')
    core = req('GET', '')
    out = {'site': core.get('name'), 'url': core.get('url') or core.get('home'), 'namespaces': core.get('namespaces', [])[:12], 'bridge': False}
    if 'forge/v1' in core.get('namespaces', []):
        out['bridge'] = True; out.update(req('GET', 'forge/v1/status'))
    else:
        me = req('GET', 'wp/v2/users/me?context=edit'); out['user'] = me.get('slug'); out['caps'] = [k for k, v in (me.get('capabilities') or {}).items() if v and k in ('edit_pages', 'unfiltered_html', 'upload_files', 'manage_options')]
        out['elementor'] = 'elementor/v1' in core.get('namespaces', []) or None
    return out

# ---------- media ----------
def optimise(path, max_px=1600, webp=True, quality=82):
    """Resize to max_px on the long edge and re-encode as WebP (or keep type). Returns (bytes, filename, mime, w, h)."""
    from PIL import Image, ImageOps
    im = Image.open(path); im = ImageOps.exif_transpose(im); w, h = im.size
    if max(w, h) > max_px:
        r = max_px / max(w, h); im = im.resize((round(w * r), round(h * r)), Image.LANCZOS); w, h = im.size
    base = re.sub(r'[^a-z0-9]+', '-', os.path.splitext(os.path.basename(path))[0].lower()).strip('-')
    buf = io.BytesIO()
    if webp and im.mode in ('RGB', 'RGBA', 'P', 'L'):
        (im.convert('RGBA') if im.mode in ('P', 'RGBA') else im.convert('RGB')).save(buf, 'WEBP', quality=quality, method=6); return buf.getvalue(), base + '.webp', 'image/webp', w, h
    fmt = (im.format or 'JPEG'); im.save(buf, fmt, quality=quality); return buf.getvalue(), base + '.' + fmt.lower().replace('jpeg', 'jpg'), Image.MIME.get(fmt, 'image/jpeg'), w, h

def media_find(q, n=10):
    if has_bridge(): return req('GET', f'forge/v1/media/find?q={requests.utils.quote(q)}&per_page={n}')
    rows = req('GET', f'wp/v2/media?search={requests.utils.quote(q)}&per_page={n}&_fields=id,title,source_url,mime_type,alt_text,media_details')
    return [{'id': r['id'], 'title': r['title']['rendered'], 'url': r['source_url'], 'mime': r['mime_type'], 'alt': r.get('alt_text', ''), 'width': (r.get('media_details') or {}).get('width'), 'height': (r.get('media_details') or {}).get('height')} for r in rows]

def media_get(mid):
    r = req('GET', f'wp/v2/media/{mid}?_fields=id,title,source_url,mime_type,alt_text,media_details')
    return {'id': r['id'], 'title': r['title']['rendered'], 'url': r['source_url'], 'mime': r['mime_type'], 'alt': r.get('alt_text', ''), 'width': (r.get('media_details') or {}).get('width'), 'height': (r.get('media_details') or {}).get('height')}

def media_upload(path, alt='', title='', caption='', reuse=True, max_px=1600, webp=True, rename=None):
    mime, _ = mimetypes.guess_type(path); mime = mime or 'application/octet-stream'; data = None; fname = os.path.basename(path); w = h = None
    if mime.startswith('image/') and mime not in ('image/svg+xml', 'image/gif'):
        data, fname, mime, w, h = optimise(path, max_px, webp)
    else:
        data = open(path, 'rb').read()
    if rename: fname = rename + os.path.splitext(fname)[1]
    if reuse:
        stem = os.path.splitext(fname)[0]
        for m in media_find(stem, 5):
            if m['url'] and os.path.splitext(os.path.basename(m['url']))[0].startswith(stem) and m['mime'] == mime:
                if alt and m.get('alt') != alt: req('POST', f'wp/v2/media/{m["id"]}', json={'alt_text': alt})
                m['reused'] = True; return m
    r = S.post(api('wp/v2/media'), data=data, headers={'Content-Type': mime, 'Content-Disposition': f'attachment; filename="{fname}"'}, timeout=300, verify=VERIFY)
    if r.status_code >= 400: raise RuntimeError(f'upload {fname} → {r.status_code}: {r.text[:300]}')
    j = r.json(); mid = j['id']
    patch = {k: v for k, v in {'alt_text': alt, 'title': title or os.path.splitext(fname)[0].replace('-', ' '), 'caption': caption, 'description': alt}.items() if v}
    if patch: req('POST', f'wp/v2/media/{mid}', json=patch)
    det = j.get('media_details') or {}
    return {'id': mid, 'url': j['source_url'], 'mime': j['mime_type'], 'alt': alt, 'width': det.get('width') or w, 'height': det.get('height') or h, 'title': patch.get('title', '')}

def media_resolve(bp, assets_dir='.', reuse=True, dry=False, existing=None):
    """Resolve every media slot in the blueprint. source: local path | http(s) URL | library:<query> | library:<id>."""
    out = dict(existing or {}); slug = bp['page']['slug']
    for key, spec in (bp.get('media') or {}).items():
        if key in out and out[key].get('url'): continue
        src = spec.get('source', ''); kind = spec.get('kind', 'image'); alt = spec.get('alt', '')
        if src.startswith('library:'):
            q = src[8:].strip()
            if q.isdigit(): m = media_get(int(q))
            else:
                hits = media_find(q, 5) or media_find(re.sub(r'\s+', '-', q), 5); m = hits[0] if hits else None
            if not m: print(f'  ! {key}: nothing in the library for "{q}"'); continue
            if alt and m.get('alt') != alt and not dry: req('POST', f'wp/v2/media/{m["id"]}', json={'alt_text': alt}); m['alt'] = alt
            out[key] = dict(m, kind=kind); print(f'  ✓ {key}: library #{m["id"]} {m["url"]}'); continue
        if re.match(r'^https?://', src):
            if kind == 'video' or re.search(r'(youtube\.com|youtu\.be|vimeo\.com)', src): out[key] = {'id': 0, 'url': src, 'alt': alt, 'kind': kind}; print(f'  ✓ {key}: external {src}'); continue
            r = requests.get(src, timeout=120); r.raise_for_status(); tmp = os.path.join(assets_dir, f'.forge-{key}{os.path.splitext(src.split("?")[0])[1] or ".jpg"}'); open(tmp, 'wb').write(r.content); src = tmp
        p = src if os.path.isabs(src) else os.path.join(assets_dir, src)
        if not os.path.exists(p): print(f'  ! {key}: file not found {p}'); continue
        if dry: out[key] = {'id': 0, 'url': 'file://' + p, 'alt': alt, 'kind': kind}; continue
        m = media_upload(p, alt=alt, title=spec.get('title', ''), caption=spec.get('caption', ''), reuse=reuse, max_px=1920 if spec.get('priority') else 1600, webp=kind == 'image', rename=f"{slug}-{key}" if spec.get('rename', True) else None)
        m['kind'] = kind; out[key] = m; print(f'  ✓ {key}: {"reused" if m.get("reused") else "uploaded"} #{m["id"]} {m["url"]}')
    return out

# ---------- pages ----------
def import_bundle(bundle, status=None, media=None):
    if status: bundle['status'] = status
    if media and not bundle.get('featured_media'):
        hero = next((s.get('media') for s in bundle['blueprint']['sections'] if s['type'] == 'hero' and s.get('media')), None)
        if hero and media.get(hero, {}).get('id'): bundle['featured_media'] = media[hero]['id']
    if has_bridge(): return req('POST', 'forge/v1/import', json=bundle)
    # no bridge: core REST only — HTML fallback content, no Elementor data, SEO via registered meta if the SEO plugin exposes it
    print('  ! bridge not installed: importing HTML content only (no Elementor data, no JSON-LD). Install forge-bridge.php for the full deploy.', file=sys.stderr)
    pt = 'posts' if bundle.get('post_type') == 'post' else 'pages'
    ex = req('GET', f'wp/v2/{pt}?slug={bundle["slug"]}&status=any&_fields=id')
    body = {'slug': bundle['slug'], 'title': bundle['post_title'], 'status': bundle.get('status', 'draft'), 'content': bundle.get('content_html', ''), 'excerpt': bundle.get('summary', '')}
    if bundle.get('featured_media'): body['featured_media'] = bundle['featured_media']
    r = req('POST', f'wp/v2/{pt}/{ex[0]["id"]}' if ex else f'wp/v2/{pt}', json=body)
    return {'id': r['id'], 'link': r.get('link'), 'updated': bool(ex), 'bridge': False}

def import_template(tpl):
    if not has_bridge(): die('the bridge is required for saved-template import; alternatively import the JSON file via Elementor → Templates → Import Templates')
    return req('POST', 'forge/v1/template', json={'title': tpl['title'], 'content': tpl['content'], 'page_settings': tpl.get('page_settings', {}), 'type': tpl.get('type', 'page')})

def settings(**kw):
    body = {k: v for k, v in kw.items() if v is not None}
    return req('POST', 'forge/v1/settings', json=body) if body else req('GET', 'forge/v1/settings')

# ---------- verification ----------
def verify(url):
    r = requests.get(url, timeout=60, headers={'User-Agent': S.headers['User-Agent']}, verify=VERIFY); h = r.text
    g = lambda pat: [re.sub(r'\s+', ' ', x).strip() for x in re.findall(pat, h, re.I | re.S)]
    ld = [];
    for blk in re.findall(r'<script[^>]*application/ld\+json[^>]*>(.*?)</script>', h, re.I | re.S):
        try: j = json.loads(blk); ld.extend([x.get('@type') for x in (j.get('@graph') if isinstance(j, dict) and '@graph' in j else [j])])
        except Exception as e: ld.append('INVALID JSON-LD: ' + str(e)[:60])
    imgs = re.findall(r'<img\b[^>]*>', h, re.I); noalt = [i for i in imgs if not re.search(r'\balt="[^"]+"', i)]
    return {'status': r.status_code, 'bytes': len(h), 'title': (g(r'<title[^>]*>(.*?)</title>') or [''])[0], 'meta_description': (g(r'<meta\s+name="description"\s+content="([^"]*)"') or [''])[0], 'canonical': (g(r'<link\s+rel="canonical"\s+href="([^"]*)"') or [''])[0], 'robots': g(r'<meta\s+name="robots"\s+content="([^"]*)"'), 'h1': g(r'<h1[^>]*>(.*?)</h1>'), 'h2_count': len(g(r'<h2[^>]*>')), 'jsonld_types': ld, 'images': len(imgs), 'images_without_alt': len(noalt), 'has_form': bool(re.search(r'<form\b', h, re.I)), 'elementor': 'elementor' in h, 'lazy_images': len(re.findall(r'loading="lazy"', h))}

# ---------- sitemap + internal-link check (never link to a URL that is not live) ----------
def sitemap_urls(base=None, limit=5000):
    base = (base or WP).rstrip('/'); seen = set(); out = []
    def grab(u, depth=0):
        if depth > 2 or len(out) >= limit: return
        try: t = requests.get(u, timeout=30, headers={'User-Agent': S.headers['User-Agent']}, verify=VERIFY).text
        except Exception: return
        subs = re.findall(r'<sitemap>\s*<loc>(.*?)</loc>', t, re.S)
        for s_ in subs: grab(s_.strip(), depth + 1)
        for loc in re.findall(r'<url>\s*<loc>(.*?)</loc>', t, re.S):
            l = loc.strip()
            if l not in seen: seen.add(l); out.append(l)
    for cand in ('/sitemap_index.xml', '/sitemap.xml', '/wp-sitemap.xml'):
        grab(base + cand)
        if out: break
    return out
def links_check(bp, base=None):
    base = (base or WP or bp.get('site', {}).get('url', '')).rstrip('/'); urls = set(u.rstrip('/') for u in sitemap_urls(base)); res = []; seen = set()
    for l in bp['page'].get('internal_links', []) + [x for s in bp['sections'] if s['type'] == 'links' for x in s.get('items', [])]:
        u = l['url'] if re.match(r'^https?://', l['url']) else base + l['url']
        if u in seen: continue
        seen.add(u); ok = u.rstrip('/') in urls; how = 'sitemap'
        if not ok:
            try: ok = requests.head(u, timeout=20, allow_redirects=True, headers={'User-Agent': S.headers['User-Agent']}, verify=VERIFY).status_code < 400; how = 'HEAD'
            except Exception: ok = False
        res.append({'anchor': l['anchor'], 'url': u, 'live': ok, 'via': how if ok else 'missing'})
    return res
def bridge_zip(src, out='forge-bridge.zip'):
    import zipfile
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z: z.write(src, 'forge-bridge/forge-bridge.php')
    return out

# ---------- CLI ----------
def main(a):
    if not a: print(__doc__); return
    cmd = a[0]; opt = lambda k, d=None: (a[a.index(k) + 1] if k in a else d); flag = lambda k: k in a
    if cmd == 'status': print(json.dumps(status(), indent=1))
    elif cmd == 'media-find': print(json.dumps(media_find(a[1]), indent=1))
    elif cmd == 'media-upload': print(json.dumps(media_upload(a[1], alt=opt('--alt', ''), title=opt('--title', ''), caption=opt('--caption', ''), reuse=flag('--reuse'), max_px=int(opt('--max', 1600)), webp=flag('--webp') or True), indent=1))
    elif cmd == 'media-resolve':
        bp = json.load(open(a[1], encoding='utf-8')); out_path = a[2]; existing = json.load(open(out_path, encoding='utf-8')) if os.path.exists(out_path) else {}
        m = media_resolve(bp, opt('--assets', '.'), reuse=flag('--reuse'), dry=flag('--dry'), existing=existing); json.dump(m, open(out_path, 'w', encoding='utf-8'), indent=1); print('wrote', out_path, len(m), 'slots')
    elif cmd == 'import':
        b = json.load(open(a[1], encoding='utf-8')); media = json.load(open(opt('--media'), encoding='utf-8')) if opt('--media') else None
        print(json.dumps(import_bundle(b, opt('--status'), media), indent=1))
    elif cmd == 'template': print(json.dumps(import_template(json.load(open(a[1], encoding='utf-8'))), indent=1))
    elif cmd == 'settings': print(json.dumps(settings(revalidate_url=opt('--revalidate-url'), revalidate_secret=opt('--secret'), cors_origins=(opt('--cors').split(',') if opt('--cors') else None), lead_email=opt('--lead-email'), indexnow_key=opt('--indexnow-key')), indent=1))
    elif cmd == 'verify': print(json.dumps(verify(a[1]), indent=1))
    elif cmd == 'indexnow': print(json.dumps(req('POST', 'forge/v1/indexnow', json={'urls': a[1:]}), indent=1))
    elif cmd == 'sitemap': [print(u) for u in sitemap_urls(opt('--base'))]
    elif cmd == 'links-check':
        r = links_check(json.load(open(a[1], encoding='utf-8')), opt('--base')); print(json.dumps(r, indent=1))
        if any(not x['live'] for x in r): die('one or more internal links are not live — remove or fix them before deploy', 2)
    elif cmd == 'bridge-zip': print('wrote', bridge_zip(a[1] if len(a) > 1 else 'forge-bridge.php'))
    else: die('unknown command ' + cmd)

if __name__ == '__main__':
    try: main(sys.argv[1:])
    except RuntimeError as e: die(str(e))
