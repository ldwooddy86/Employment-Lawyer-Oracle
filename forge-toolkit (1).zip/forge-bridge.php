<?php
/**
 * Plugin Name: FORGE Bridge
 * Description: REST bridge for FORGE — imports compiled pages (Elementor data, HTML fallback, SEO, JSON-LD), exposes the blueprint to headless front ends, serves llms.txt, accepts leads, pings headless revalidation, lists live URLs, and opens CORS for allowed origins (browser-side deploys).
 * Version: 1.1.0
 * Author: FORGE
 * Requires at least: 6.2
 * Requires PHP: 7.4
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Forge_Bridge {
	const NS = 'forge/v1';
	const VER = '1.1.0';
	const OPT = 'forge_bridge_settings';

	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
		add_action( 'rest_api_init', [ __CLASS__, 'fields' ] );
		add_action( 'wp_head', [ __CLASS__, 'head' ], 1 );
		add_filter( 'pre_get_document_title', [ __CLASS__, 'title' ], 99 );
		add_action( 'save_post', [ __CLASS__, 'on_save' ], 20, 3 );
		add_action( 'template_redirect', [ __CLASS__, 'llms_txt' ] );
		add_filter( 'rest_pre_serve_request', [ __CLASS__, 'cors' ], 10, 4 );
		add_filter( 'upload_mimes', [ __CLASS__, 'mimes' ] );
	}

	/* ---------- settings ---------- */
	public static function settings() {
		$d = [ 'revalidate_url' => '', 'revalidate_secret' => '', 'cors_origins' => [], 'lead_email' => get_option( 'admin_email' ), 'indexnow_key' => '', 'llms_intro' => '' ];
		$s = get_option( self::OPT, [] );
		return is_array( $s ) ? array_merge( $d, $s ) : $d;
	}

	/* ---------- capability ---------- */
	public static function can_edit() { return current_user_can( 'edit_pages' ); }
	public static function can_admin() { return current_user_can( 'manage_options' ); }

	/* ---------- routes ---------- */
	public static function routes() {
		register_rest_route( self::NS, '/status', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'r_status' ], 'permission_callback' => [ __CLASS__, 'can_edit' ] ] );
		register_rest_route( self::NS, '/import', [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'r_import' ], 'permission_callback' => [ __CLASS__, 'can_edit' ] ] );
		register_rest_route( self::NS, '/template', [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'r_template' ], 'permission_callback' => [ __CLASS__, 'can_edit' ] ] );
		register_rest_route( self::NS, '/settings', [ [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'r_get_settings' ], 'permission_callback' => [ __CLASS__, 'can_admin' ] ], [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'r_set_settings' ], 'permission_callback' => [ __CLASS__, 'can_admin' ] ] ] );
		register_rest_route( self::NS, '/media/find', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'r_media_find' ], 'permission_callback' => [ __CLASS__, 'can_edit' ] ] );
		register_rest_route( self::NS, '/nav', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'r_nav' ], 'permission_callback' => '__return_true' ] );
		register_rest_route( self::NS, '/lead', [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'r_lead' ], 'permission_callback' => '__return_true' ] );
		register_rest_route( self::NS, '/indexnow', [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'r_indexnow' ], 'permission_callback' => [ __CLASS__, 'can_edit' ] ] );
		register_rest_route( self::NS, '/urls', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'r_urls' ], 'permission_callback' => [ __CLASS__, 'can_edit' ] ] );
		register_rest_route( self::NS, '/pages', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'r_pages' ], 'permission_callback' => [ __CLASS__, 'can_edit' ] ] );
	}

	/* ---------- public REST field: blueprint + seo + schema on pages/posts ---------- */
	public static function fields() {
		foreach ( [ 'page', 'post' ] as $pt ) {
			register_rest_field( $pt, 'forge', [
				'get_callback' => function ( $obj ) {
					$id = (int) $obj['id'];
					return [
						'blueprint' => self::json_meta( $id, '_forge_blueprint' ),
						'schema'    => self::json_meta( $id, '_forge_schema' ),
						'seo'       => self::json_meta( $id, '_forge_seo' ),
						'summary'   => get_post_meta( $id, '_forge_summary', true ),
					];
				},
				'schema' => [ 'type' => 'object', 'context' => [ 'view' ] ],
			] );
		}
	}
	private static function json_meta( $id, $key ) {
		$v = get_post_meta( $id, $key, true );
		if ( ! $v ) { return null; }
		$j = json_decode( $v, true );
		return null === $j ? null : $j;
	}

	/* ---------- status ---------- */
	public static function r_status() {
		global $wp_version;
		$el = defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : null;
		$seo = 'none';
		if ( defined( 'WPSEO_VERSION' ) ) { $seo = 'yoast'; }
		elseif ( defined( 'RANK_MATH_VERSION' ) ) { $seo = 'rankmath'; }
		elseif ( defined( 'SEOPRESS_VERSION' ) ) { $seo = 'seopress'; }
		elseif ( defined( 'AIOSEO_VERSION' ) ) { $seo = 'aioseo'; }
		$forms = [
			'elementor_pro' => defined( 'ELEMENTOR_PRO_VERSION' ),
			'wpforms'       => defined( 'WPFORMS_VERSION' ),
			'gravity'       => class_exists( 'GFForms' ),
			'cf7'           => defined( 'WPCF7_VERSION' ),
			'fluent'        => defined( 'FLUENTFORM' ),
		];
		return [
			'forge'          => self::VER,
			'wp'             => $wp_version,
			'php'            => PHP_VERSION,
			'home'           => home_url( '/' ),
			'rest'           => rest_url( self::NS ),
			'elementor'      => $el,
			'elementor_pro'  => defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : null,
			'containers'     => $el ? self::containers_active() : false,
			'theme'          => wp_get_theme()->get( 'Name' ),
			'permalinks'     => get_option( 'permalink_structure' ),
			'seo_plugin'     => $seo,
			'forms'          => $forms,
			'wpgraphql'      => class_exists( 'WPGraphQL' ),
			'upload_max'     => wp_max_upload_size(),
			'mime'           => array_values( array_unique( get_allowed_mime_types() ) ),
			'unfiltered_html'=> current_user_can( 'unfiltered_html' ),
			'user'           => wp_get_current_user()->user_login,
			'cors_origins'   => self::settings()['cors_origins'],
			'settings'       => self::can_admin() ? self::settings() : null,
		];
	}

	private static function containers_active() {
		if ( ! class_exists( '\Elementor\Plugin' ) ) { return false; }
		$ex = \Elementor\Plugin::$instance->experiments;
		return $ex->get_features( 'container' ) ? (bool) $ex->is_feature_active( 'container' ) : true; // experiment retired to core = containers on
	}

	/* ---------- import a compiled bundle onto a page ---------- */
	public static function r_import( WP_REST_Request $r ) {
		$b = $r->get_json_params();
		if ( empty( $b['slug'] ) || empty( $b['post_title'] ) ) { return new WP_Error( 'forge_bad', 'slug and post_title are required', [ 'status' => 400 ] ); }
		$pt = ! empty( $b['post_type'] ) && post_type_exists( $b['post_type'] ) ? $b['post_type'] : 'page';
		$slug = sanitize_title( $b['slug'] );
		$existing = get_page_by_path( $slug, OBJECT, $pt );
		$status = ! empty( $b['status'] ) && in_array( $b['status'], [ 'draft', 'publish', 'pending', 'private' ], true ) ? $b['status'] : 'draft';
		$content = isset( $b['content_html'] ) ? ( current_user_can( 'unfiltered_html' ) ? $b['content_html'] : wp_kses_post( $b['content_html'] ) ) : '';
		$args = [ 'post_type' => $pt, 'post_name' => $slug, 'post_title' => wp_strip_all_tags( $b['post_title'] ), 'post_status' => $status, 'post_content' => $content ];
		if ( ! empty( $b['excerpt'] ) ) { $args['post_excerpt'] = wp_strip_all_tags( $b['excerpt'] ); }
		if ( ! empty( $b['parent'] ) ) { $args['post_parent'] = (int) $b['parent']; }
		if ( $existing ) { $args['ID'] = $existing->ID; $id = wp_update_post( wp_slash( $args ), true ); }
		else { $id = wp_insert_post( wp_slash( $args ), true ); }
		if ( is_wp_error( $id ) ) { return $id; }

		// Elementor
		if ( ! empty( $b['elementor_data'] ) ) {
			if ( ! current_user_can( 'unfiltered_html' ) ) { return new WP_Error( 'forge_caps', 'Importing Elementor data requires the unfiltered_html capability (an administrator on single-site).', [ 'status' => 403 ] ); }
			update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( $b['elementor_data'] ) ) );
			update_post_meta( $id, '_elementor_edit_mode', 'builder' );
			update_post_meta( $id, '_elementor_template_type', 'post' === $pt ? 'wp-post' : 'wp-page' );
			if ( defined( 'ELEMENTOR_VERSION' ) ) { update_post_meta( $id, '_elementor_version', ELEMENTOR_VERSION ); }
			if ( ! empty( $b['page_settings'] ) && is_array( $b['page_settings'] ) ) { update_post_meta( $id, '_elementor_page_settings', $b['page_settings'] ); }
			$tpl = ! empty( $b['template'] ) ? $b['template'] : ( ! empty( $b['page_settings']['template'] ) ? $b['page_settings']['template'] : 'default' );
			if ( in_array( $tpl, [ 'elementor_header_footer', 'elementor_canvas', 'elementor_theme' ], true ) ) { update_post_meta( $id, '_wp_page_template', $tpl ); }
			else { delete_post_meta( $id, '_wp_page_template' ); }
			delete_post_meta( $id, '_elementor_css' );
			if ( class_exists( '\Elementor\Plugin' ) ) { \Elementor\Plugin::$instance->files_manager->clear_cache(); }
		}
		// FORGE meta
		foreach ( [ 'blueprint' => '_forge_blueprint', 'schema' => '_forge_schema', 'seo' => '_forge_seo' ] as $k => $meta ) {
			if ( isset( $b[ $k ] ) ) { update_post_meta( $id, $meta, wp_slash( wp_json_encode( $b[ $k ] ) ) ); }
		}
		if ( isset( $b['summary'] ) ) { update_post_meta( $id, '_forge_summary', sanitize_text_field( $b['summary'] ) ); }
		if ( ! empty( $b['featured_media'] ) ) { set_post_thumbnail( $id, (int) $b['featured_media'] ); }
		// SEO plugin fields
		if ( ! empty( $b['seo'] ) ) { self::write_seo( $id, $b['seo'] ); }
		return [ 'id' => $id, 'slug' => $slug, 'status' => $status, 'link' => get_permalink( $id ), 'edit' => get_edit_post_link( $id, 'raw' ), 'updated' => (bool) $existing ];
	}
	private static function write_seo( $id, $seo ) {
		$t = isset( $seo['title'] ) ? sanitize_text_field( $seo['title'] ) : '';
		$d = isset( $seo['description'] ) ? sanitize_text_field( $seo['description'] ) : '';
		$c = isset( $seo['canonical'] ) ? esc_url_raw( $seo['canonical'] ) : '';
		$noindex = ! empty( $seo['noindex'] );
		if ( defined( 'WPSEO_VERSION' ) ) {
			update_post_meta( $id, '_yoast_wpseo_title', $t ); update_post_meta( $id, '_yoast_wpseo_metadesc', $d );
			if ( $c ) { update_post_meta( $id, '_yoast_wpseo_canonical', $c ); }
			update_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', $noindex ? '1' : '2' );
		} elseif ( defined( 'RANK_MATH_VERSION' ) ) {
			update_post_meta( $id, 'rank_math_title', $t ); update_post_meta( $id, 'rank_math_description', $d );
			if ( $c ) { update_post_meta( $id, 'rank_math_canonical_url', $c ); }
			update_post_meta( $id, 'rank_math_robots', $noindex ? [ 'noindex' ] : [ 'index' ] );
		} elseif ( defined( 'SEOPRESS_VERSION' ) ) {
			update_post_meta( $id, '_seopress_titles_title', $t ); update_post_meta( $id, '_seopress_titles_desc', $d );
			if ( $c ) { update_post_meta( $id, '_seopress_robots_canonical', $c ); }
			update_post_meta( $id, '_seopress_robots_index', $noindex ? 'yes' : '' );
		}
		// AIOSEO keeps its own table; the bridge's own head output covers the no-plugin case.
	}

	/* ---------- import an Elementor library template (Saved Templates) ---------- */
	public static function r_template( WP_REST_Request $r ) {
		$b = $r->get_json_params();
		if ( empty( $b['content'] ) || empty( $b['title'] ) ) { return new WP_Error( 'forge_bad', 'title and content are required', [ 'status' => 400 ] ); }
		if ( ! current_user_can( 'unfiltered_html' ) ) { return new WP_Error( 'forge_caps', 'unfiltered_html required', [ 'status' => 403 ] ); }
		if ( ! post_type_exists( 'elementor_library' ) ) { return new WP_Error( 'forge_noel', 'Elementor is not active', [ 'status' => 409 ] ); }
		$id = wp_insert_post( wp_slash( [ 'post_type' => 'elementor_library', 'post_title' => wp_strip_all_tags( $b['title'] ), 'post_status' => 'publish' ] ), true );
		if ( is_wp_error( $id ) ) { return $id; }
		update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( $b['content'] ) ) );
		update_post_meta( $id, '_elementor_edit_mode', 'builder' );
		update_post_meta( $id, '_elementor_template_type', ! empty( $b['type'] ) ? sanitize_key( $b['type'] ) : 'page' );
		if ( defined( 'ELEMENTOR_VERSION' ) ) { update_post_meta( $id, '_elementor_version', ELEMENTOR_VERSION ); }
		if ( ! empty( $b['page_settings'] ) ) { update_post_meta( $id, '_elementor_page_settings', $b['page_settings'] ); }
		wp_set_object_terms( $id, ! empty( $b['type'] ) ? sanitize_key( $b['type'] ) : 'page', 'elementor_library_type' );
		return [ 'id' => $id, 'edit' => get_edit_post_link( $id, 'raw' ) ];
	}

	/* ---------- settings ---------- */
	public static function r_get_settings() { return self::settings(); }
	public static function r_set_settings( WP_REST_Request $r ) {
		$b = $r->get_json_params(); $s = self::settings();
		foreach ( [ 'revalidate_url', 'revalidate_secret', 'lead_email', 'indexnow_key', 'llms_intro' ] as $k ) { if ( isset( $b[ $k ] ) ) { $s[ $k ] = sanitize_text_field( $b[ $k ] ); } }
		if ( isset( $b['cors_origins'] ) && is_array( $b['cors_origins'] ) ) { $s['cors_origins'] = array_values( array_filter( array_map( function ( $o ) { $o = trim( (string) $o ); return ( '*' === $o || 'null' === $o ) ? $o : esc_url_raw( $o ); }, $b['cors_origins'] ) ) ); }
		update_option( self::OPT, $s );
		return $s;
	}

	/* ---------- media search (title, filename, alt) ---------- */
	public static function r_media_find( WP_REST_Request $r ) {
		$q = sanitize_text_field( $r->get_param( 'q' ) ); $n = min( 50, max( 1, (int) $r->get_param( 'per_page' ) ?: 20 ) );
		$posts = get_posts( [ 'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => $n, 's' => $q ] );
		$out = [];
		foreach ( $posts as $p ) {
			$meta = wp_get_attachment_metadata( $p->ID );
			$out[] = [ 'id' => $p->ID, 'title' => $p->post_title, 'url' => wp_get_attachment_url( $p->ID ), 'mime' => $p->post_mime_type, 'alt' => get_post_meta( $p->ID, '_wp_attachment_image_alt', true ), 'width' => $meta['width'] ?? null, 'height' => $meta['height'] ?? null, 'file' => $meta['file'] ?? '' ];
		}
		return $out;
	}

	/* ---------- public nav for headless ---------- */
	public static function r_nav( WP_REST_Request $r ) {
		$loc = sanitize_key( $r->get_param( 'location' ) ?: 'primary' );
		$locs = get_nav_menu_locations(); $menu = null;
		if ( ! empty( $locs[ $loc ] ) ) { $menu = wp_get_nav_menu_object( $locs[ $loc ] ); }
		if ( ! $menu ) { $menus = wp_get_nav_menus(); $menu = $menus ? $menus[0] : null; }
		if ( ! $menu ) { return [ 'items' => [] ]; }
		$items = wp_get_nav_menu_items( $menu->term_id ) ?: []; $out = [];
		foreach ( $items as $it ) { $out[] = [ 'id' => $it->ID, 'parent' => (int) $it->menu_item_parent, 'title' => $it->title, 'url' => $it->url, 'target' => $it->target ]; }
		return [ 'menu' => $menu->name, 'items' => $out ];
	}

	/* ---------- leads from the HTML form (Elementor html widget or headless) ---------- */
	public static function r_lead( WP_REST_Request $r ) {
		$b = $r->get_json_params(); if ( ! $b ) { $b = $r->get_body_params(); }
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$key = 'forge_lead_' . md5( $ip ); $n = (int) get_transient( $key );
		if ( $n >= 8 ) { return new WP_Error( 'forge_rate', 'Too many submissions; please call us.', [ 'status' => 429 ] ); }
		set_transient( $key, $n + 1, HOUR_IN_SECONDS );
		if ( ! empty( $b['website'] ) ) { return [ 'ok' => true, 'message' => 'Thanks.' ]; } // honeypot
		$email = isset( $b['email'] ) ? sanitize_email( $b['email'] ) : '';
		$phone = isset( $b['phone'] ) ? sanitize_text_field( $b['phone'] ) : '';
		if ( ! $email && ! $phone ) { return new WP_Error( 'forge_bad', 'A phone number or email is required.', [ 'status' => 400 ] ); }
		if ( empty( $b['consent'] ) ) { return new WP_Error( 'forge_consent', 'Please tick the consent box.', [ 'status' => 400 ] ); }
		$fields = [];
		foreach ( $b as $k => $v ) { if ( is_scalar( $v ) ) { $fields[ sanitize_key( $k ) ] = sanitize_textarea_field( (string) $v ); } }
		$id = wp_insert_post( [ 'post_type' => 'forge_lead', 'post_status' => 'private', 'post_title' => ( $fields['name'] ?? 'Lead' ) . ' — ' . ( $fields['page'] ?? '' ) . ' — ' . current_time( 'mysql' ), 'post_content' => wp_json_encode( $fields ) ] );
		$s = self::settings();
		$body = '';
		foreach ( $fields as $k => $v ) { $body .= ucfirst( $k ) . ": $v\n"; }
		wp_mail( $s['lead_email'], 'New lead: ' . ( $fields['page'] ?? get_bloginfo( 'name' ) ), $body . "\nIP: $ip\n" );
		return [ 'ok' => true, 'id' => $id, 'message' => 'Thanks — we will be in touch shortly.' ];
	}

	/* ---------- live URLs (for internal-link checks) and slug lookup ---------- */
	public static function r_urls( WP_REST_Request $r ) {
		$types = array_values( array_filter( get_post_types( [ 'public' => true ] ), function ( $t ) { return 'attachment' !== $t; } ) );
		$ids = get_posts( [ 'post_type' => $types, 'post_status' => 'publish', 'posts_per_page' => 5000, 'fields' => 'ids', 'no_found_rows' => true ] );
		$urls = [ home_url( '/' ) ];
		foreach ( $ids as $id ) { $urls[] = get_permalink( $id ); }
		return [ 'count' => count( $urls ), 'urls' => array_values( array_unique( $urls ) ) ];
	}
	public static function r_pages( WP_REST_Request $r ) {
		$slugs = array_filter( array_map( 'sanitize_title', explode( ',', (string) $r->get_param( 'slugs' ) ) ) ); $out = [];
		foreach ( $slugs as $slug ) {
			foreach ( [ 'page', 'post' ] as $pt ) {
				$p = get_page_by_path( $slug, OBJECT, $pt );
				if ( $p ) { $out[ $slug ] = [ 'id' => $p->ID, 'type' => $pt, 'status' => $p->post_status, 'link' => get_permalink( $p ), 'edit' => get_edit_post_link( $p->ID, 'raw' ), 'modified' => $p->post_modified_gmt ]; break; }
			}
		}
		return $out;
	}

	/* ---------- IndexNow ---------- */
	public static function r_indexnow( WP_REST_Request $r ) {
		$s = self::settings(); if ( ! $s['indexnow_key'] ) { return new WP_Error( 'forge_key', 'Set indexnow_key in settings first', [ 'status' => 400 ] ); }
		$urls = array_values( array_filter( array_map( 'esc_url_raw', (array) $r->get_param( 'urls' ) ) ) );
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$res = wp_remote_post( 'https://api.indexnow.org/indexnow', [ 'headers' => [ 'Content-Type' => 'application/json' ], 'body' => wp_json_encode( [ 'host' => $host, 'key' => $s['indexnow_key'], 'keyLocation' => home_url( '/' . $s['indexnow_key'] . '.txt' ), 'urlList' => $urls ] ), 'timeout' => 15 ] );
		return [ 'sent' => count( $urls ), 'code' => is_wp_error( $res ) ? $res->get_error_message() : wp_remote_retrieve_response_code( $res ) ];
	}

	/* ---------- head output: JSON-LD always; title/meta/canonical only without an SEO plugin ---------- */
	private static function has_seo_plugin() { return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || defined( 'AIOSEO_VERSION' ); }
	public static function title( $t ) {
		if ( self::has_seo_plugin() || ! is_singular() ) { return $t; }
		$seo = self::json_meta( get_queried_object_id(), '_forge_seo' );
		return ! empty( $seo['title'] ) ? $seo['title'] : $t;
	}
	public static function head() {
		if ( ! is_singular() ) { return; }
		$id = get_queried_object_id();
		$schema = self::json_meta( $id, '_forge_schema' );
		if ( $schema ) { echo "\n" . '<script type="application/ld+json">' . str_replace( '</', '<\/', wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ) . '</script>' . "\n"; } // phpcs:ignore WordPress.Security.EscapeOutput
		if ( self::has_seo_plugin() ) { return; }
		$seo = self::json_meta( $id, '_forge_seo' );
		if ( ! $seo ) { return; }
		if ( ! empty( $seo['description'] ) ) { echo '<meta name="description" content="' . esc_attr( $seo['description'] ) . '">' . "\n"; }
		if ( ! empty( $seo['noindex'] ) ) { echo '<meta name="robots" content="noindex,follow">' . "\n"; }
		$canon = ! empty( $seo['canonical'] ) ? $seo['canonical'] : get_permalink( $id );
		echo '<link rel="canonical" href="' . esc_url( $canon ) . '">' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( $seo['title'] ?? get_the_title( $id ) ) . '"><meta property="og:type" content="website"><meta property="og:url" content="' . esc_url( $canon ) . '">' . "\n";
		if ( ! empty( $seo['og_image'] ) ) { echo '<meta property="og:image" content="' . esc_url( $seo['og_image'] ) . '">' . "\n"; }
	}

	/* ---------- llms.txt and the IndexNow key file ---------- */
	public static function llms_txt() {
		$req = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : '';
		$s = self::settings();
		if ( $s['indexnow_key'] && $req === '/' . $s['indexnow_key'] . '.txt' ) { header( 'Content-Type: text/plain; charset=utf-8' ); echo esc_html( $s['indexnow_key'] ); exit; }
		if ( '/llms.txt' !== $req ) { return; }
		$out = get_transient( 'forge_llms_txt' );
		if ( ! $out ) {
			$out = '# ' . get_bloginfo( 'name' ) . "\n\n> " . ( $s['llms_intro'] ?: get_bloginfo( 'description' ) ) . "\n\n";
			foreach ( [ 'page' => 'Pages', 'post' => 'Articles' ] as $pt => $label ) {
				$posts = get_posts( [ 'post_type' => $pt, 'post_status' => 'publish', 'posts_per_page' => 300, 'orderby' => 'modified', 'order' => 'DESC' ] );
				if ( ! $posts ) { continue; }
				$out .= "## $label\n\n";
				foreach ( $posts as $p ) {
					$sum = get_post_meta( $p->ID, '_forge_summary', true ) ?: wp_trim_words( wp_strip_all_tags( $p->post_excerpt ?: $p->post_content ), 28, '…' );
					$out .= '- [' . $p->post_title . '](' . get_permalink( $p ) . ')' . ( $sum ? ': ' . $sum : '' ) . "\n";
				}
				$out .= "\n";
			}
			set_transient( 'forge_llms_txt', $out, HOUR_IN_SECONDS );
		}
		header( 'Content-Type: text/plain; charset=utf-8' ); echo $out; exit; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/* ---------- headless revalidation + cache bust on save ---------- */
	public static function on_save( $id, $post, $update ) {
		if ( wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) ) { return; }
		if ( ! in_array( $post->post_type, [ 'page', 'post' ], true ) ) { return; }
		delete_transient( 'forge_llms_txt' );
		$s = self::settings();
		if ( ! $s['revalidate_url'] || 'publish' !== $post->post_status ) { return; }
		$path = wp_parse_url( get_permalink( $id ), PHP_URL_PATH ) ?: '/';
		wp_remote_post( $s['revalidate_url'], [ 'timeout' => 5, 'blocking' => false, 'headers' => [ 'Content-Type' => 'application/json' ], 'body' => wp_json_encode( [ 'secret' => $s['revalidate_secret'], 'path' => $path, 'id' => $id, 'type' => $post->post_type ] ) ] );
	}

	/* ---------- CORS for the headless origin(s) ---------- */
	public static function cors( $served, $result, $request, $server ) {
		$s = self::settings(); $origin = get_http_origin(); $allowed = array_map( 'untrailingslashit', (array) $s['cors_origins'] );
		if ( $origin && ( in_array( '*', $allowed, true ) || in_array( untrailingslashit( $origin ), $allowed, true ) ) ) {
			header( 'Access-Control-Allow-Origin: ' . ( 'null' === $origin ? 'null' : esc_url_raw( $origin ) ) );
			header( 'Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS' );
			header( 'Access-Control-Allow-Headers: Content-Type, Authorization, Content-Disposition, X-WP-Nonce' );
			header( 'Access-Control-Expose-Headers: Link, X-WP-Total, X-WP-TotalPages' );
			header( 'Access-Control-Max-Age: 600' ); header( 'Vary: Origin', false );
		}
		return $served;
	}

	/* ---------- allow WebP/AVIF/MP4/WebM uploads where the host forgot (no SVG: sanitise those elsewhere) ---------- */
	public static function mimes( $m ) { $m['webp'] = 'image/webp'; $m['avif'] = 'image/avif'; $m['mp4'] = 'video/mp4'; $m['webm'] = 'video/webm'; return $m; }
}
add_action( 'init', function () {
	register_post_type( 'forge_lead', [ 'label' => 'FORGE leads', 'public' => false, 'show_ui' => true, 'show_in_menu' => true, 'menu_icon' => 'dashicons-hammer', 'supports' => [ 'title', 'editor' ], 'capability_type' => 'post', 'map_meta_cap' => true ] );
} );
Forge_Bridge::init();
