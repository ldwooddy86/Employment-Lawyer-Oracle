#!/usr/bin/env python3
"""Minimal WordPress REST mock (core media/pages + forge/v1 bridge) for testing forge_wp.py offline."""
import json, re, base64, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
DB = {'media': {}, 'pages': {}, 'templates': {}, 'settings': {'revalidate_url': '', 'revalidate_secret': '', 'cors_origins': [], 'lead_email': 'admin@example.com', 'indexnow_key': '', 'llms_intro': ''}, 'leads': []}
NEXT = {'id': 100}
def nid(): NEXT['id'] += 1; return NEXT['id']
BRIDGE = '--no-bridge' not in sys.argv
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def cors(self):
        o = self.headers.get('Origin')
        if o: self.send_header('Access-Control-Allow-Origin', o); self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS'); self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Disposition, X-WP-Nonce'); self.send_header('Vary', 'Origin')
    def do_OPTIONS(self):
        self.send_response(204); self.cors(); self.send_header('Content-Length', '0'); self.end_headers()
    def send(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code); self.cors(); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def auth(self):
        h = self.headers.get('Authorization', '')
        if not h.startswith('Basic '): self.send(401, {'code': 'rest_not_logged_in', 'message': 'You are not currently logged in.'}); return False
        u, p = base64.b64decode(h[6:]).decode().split(':', 1)
        if (u, p) != ('forge', 'abcd efgh ijkl mnop qrst uvwx'): self.send(401, {'code': 'incorrect_password', 'message': 'bad app password'}); return False
        return True
    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query); p = u.path
        if p == '/wp-json/' or p == '/wp-json': return self.send(200, {'name': 'Mock WP', 'url': 'http://127.0.0.1:8765', 'home': 'http://127.0.0.1:8765', 'namespaces': ['wp/v2'] + (['forge/v1'] if BRIDGE else [])})
        if p == '/wp-json/forge/v1/nav': return self.send(200, {'menu': 'Primary', 'items': [{'id': 1, 'parent': 0, 'title': 'Practice Areas', 'url': 'http://127.0.0.1:8765/practice-areas/', 'target': ''}, {'id': 2, 'parent': 0, 'title': 'Attorneys', 'url': 'http://127.0.0.1:8765/attorneys/', 'target': ''}]})
        if p == '/llms.txt':
            b = ('# Mock WP\n\n> Employee-side employment lawyers.\n\n## Pages\n\n' + ''.join(f"- [{v.get('bundle', {}).get('post_title', k)}](http://127.0.0.1:8765/{k}/): {v.get('bundle', {}).get('summary', '')}\n" for k, v in DB['pages'].items())).encode()
            self.send_response(200); self.send_header('Content-Type', 'text/plain; charset=utf-8'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b); return
        if p in ('/wp-json/wp/v2/pages', '/wp-json/wp/v2/posts') and 'Authorization' not in self.headers: pass
        elif not self.auth(): return
        if p == '/wp-json/wp/v2/users/me': return self.send(200, {'id': 1, 'slug': 'forge', 'capabilities': {'edit_pages': True, 'unfiltered_html': True, 'upload_files': True, 'manage_options': True}})
        if p == '/wp-json/forge/v1/status' and BRIDGE: return self.send(200, {'forge': '1.1.0', 'cors_origins': ['*'], 'wp': '6.8', 'php': '8.3', 'elementor': '3.31.0', 'elementor_pro': None, 'containers': True, 'theme': 'Hello Elementor', 'permalinks': '/%postname%/', 'seo_plugin': 'rankmath', 'forms': {'elementor_pro': False, 'wpforms': True}, 'wpgraphql': False, 'upload_max': 67108864, 'unfiltered_html': True, 'user': 'forge', 'settings': DB['settings']})
        if p == '/wp-json/forge/v1/media/find' and BRIDGE:
            s = q.get('q', [''])[0].lower(); return self.send(200, [m for m in DB['media'].values() if s in (m['title'] + ' ' + m['url']).lower()])
        if p == '/wp-json/wp/v2/media':
            s = q.get('search', [''])[0].lower(); return self.send(200, [{'id': m['id'], 'title': {'rendered': m['title']}, 'source_url': m['url'], 'mime_type': m['mime'], 'alt_text': m['alt'], 'media_details': {'width': m['width'], 'height': m['height']}} for m in DB['media'].values() if s in (m['title'] + ' ' + m['url']).lower()])
        m = re.match(r'/wp-json/wp/v2/media/(\d+)', p)
        if m:
            x = DB['media'].get(int(m.group(1)))
            if not x: return self.send(404, {'code': 'rest_post_invalid_id', 'message': 'Invalid post ID.'})
            return self.send(200, {'id': x['id'], 'title': {'rendered': x['title']}, 'source_url': x['url'], 'mime_type': x['mime'], 'alt_text': x['alt'], 'media_details': {'width': x['width'], 'height': x['height']}})
        if p in ('/wp-json/wp/v2/pages', '/wp-json/wp/v2/posts'):
            slug = q.get('slug', [''])[0]; rows = []
            for k, v in DB['pages'].items():
                if slug and k != slug: continue
                b = v.get('bundle') or {}
                rows.append({'id': v['id'], 'slug': k, 'link': f'http://127.0.0.1:8765/{k}/', 'modified_gmt': '2026-09-15T00:00:00', 'title': {'rendered': b.get('post_title', k)}, 'content': {'rendered': b.get('content_html', '')}, 'excerpt': {'rendered': ''}, 'forge': {'blueprint': b.get('blueprint'), 'schema': b.get('schema'), 'seo': b.get('seo'), 'summary': b.get('summary', '')}})
            return self.send(200, rows)
        if p == '/wp-json/forge/v1/settings' and BRIDGE: return self.send(200, DB['settings'])
        if p == '/wp-json/forge/v1/urls' and BRIDGE:
            urls = ['http://127.0.0.1:8765/'] + [f'http://127.0.0.1:8765/{k}/' for k, v in DB['pages'].items() if (v.get('bundle') or v.get('core') or {}).get('status') == 'publish']; return self.send(200, {'count': len(urls), 'urls': urls})
        if p == '/wp-json/forge/v1/pages' and BRIDGE:
            out = {}
            for sl in q.get('slugs', [''])[0].split(','):
                if sl in DB['pages']: out[sl] = {'id': DB['pages'][sl]['id'], 'type': 'page', 'status': (DB['pages'][sl].get('bundle') or {}).get('status', 'draft'), 'link': f'http://127.0.0.1:8765/{sl}/'}
            return self.send(200, out)
        self.send(404, {'code': 'rest_no_route', 'message': 'No route was found matching the URL and request method.'})
    def do_POST(self):
        u = urlparse(self.path); p = u.path; n = int(self.headers.get('Content-Length', 0)); raw = self.rfile.read(n) if n else b''
        if p == '/wp-json/forge/v1/lead': DB['leads'].append(json.loads(raw)); return self.send(200, {'ok': True, 'id': nid(), 'message': 'Thanks — we will be in touch shortly.'})
        if not self.auth(): return
        ct = self.headers.get('Content-Type', '')
        if p == '/wp-json/wp/v2/media':
            fn = re.search(r'filename="([^"]+)"', self.headers.get('Content-Disposition', '')); fn = fn.group(1) if fn else 'file.bin'
            i = nid(); DB['media'][i] = {'id': i, 'title': fn.rsplit('.', 1)[0], 'url': f'http://127.0.0.1:8765/wp-content/uploads/2026/09/{fn}', 'mime': ct, 'alt': '', 'width': 1600 if ct.startswith('image') else None, 'height': 1000 if ct.startswith('image') else None, 'bytes': len(raw)}
            return self.send(201, {'id': i, 'source_url': DB['media'][i]['url'], 'mime_type': ct, 'media_details': {'width': DB['media'][i]['width'], 'height': DB['media'][i]['height']}})
        body = json.loads(raw) if raw else {}
        m = re.match(r'/wp-json/wp/v2/media/(\d+)', p)
        if m:
            x = DB['media'][int(m.group(1))]; x['alt'] = body.get('alt_text', x['alt']); x['title'] = body.get('title', x['title']); return self.send(200, {'id': x['id']})
        if p == '/wp-json/forge/v1/import' and BRIDGE:
            if not body.get('slug') or not body.get('post_title'): return self.send(400, {'code': 'forge_bad', 'message': 'slug and post_title are required'})
            ex = DB['pages'].get(body['slug']); i = ex['id'] if ex else nid(); DB['pages'][body['slug']] = {'id': i, 'bundle': body}
            return self.send(200, {'id': i, 'slug': body['slug'], 'status': body.get('status', 'draft'), 'link': f'http://127.0.0.1:8765/{body["slug"]}/', 'edit': f'http://127.0.0.1:8765/wp-admin/post.php?post={i}&action=elementor', 'updated': bool(ex)})
        if p == '/wp-json/forge/v1/template' and BRIDGE: i = nid(); DB['templates'][i] = body; return self.send(200, {'id': i, 'edit': f'http://127.0.0.1:8765/wp-admin/post.php?post={i}&action=elementor'})
        if p == '/wp-json/forge/v1/settings' and BRIDGE: DB['settings'].update({k: v for k, v in body.items() if k in DB['settings']}); return self.send(200, DB['settings'])
        if p == '/wp-json/forge/v1/indexnow' and BRIDGE: return self.send(200, {'sent': len(body.get('urls', [])), 'code': 202})
        if p in ('/wp-json/wp/v2/pages', '/wp-json/wp/v2/posts') or re.match(r'/wp-json/wp/v2/(pages|posts)/\d+', p):
            slug = body.get('slug', 'page'); ex = DB['pages'].get(slug); i = ex['id'] if ex else nid(); DB['pages'][slug] = {'id': i, 'core': body}; return self.send(200 if ex else 201, {'id': i, 'link': f'http://127.0.0.1:8765/{slug}/'})
        self.send(404, {'code': 'rest_no_route', 'message': 'No route'})
if __name__ == '__main__':
    HTTPServer(('127.0.0.1', 8765), H).serve_forever()
