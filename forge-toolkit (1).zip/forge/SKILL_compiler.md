---
name: forge-compiler
description: Source container for the FORGE skill - carries forge_compile.py, the blueprint compiler (Elementor template, HTML fallback, preview, JSON-LD, lint). Load only from FORGE Phase 0 to materialize the toolkit; it does nothing on its own.
---

# FORGE compiler source

This skill only carries `forge/forge_compile.py` for the FORGE skill (`forge`). When FORGE Phase 0 loads it, write the block below **verbatim** to `forge/forge_compile.py` with the Write tool (one call, no edits, no reformatting), then return to FORGE. Do not run this skill on its own; if it was invoked directly, invoke `forge` instead.

### forge/forge_compile.py

```python
#!/usr/bin/env python3
"""FORGE compiler — turns a FORGE blueprint (JSON) into:
  * an Elementor template file (importable: Templates → Saved Templates → Import)
  * the _elementor_data / page settings the FORGE bridge writes straight onto a page
  * semantic HTML fallback (post_content, RSS, headless fallback)
  * a standalone preview HTML (open in a browser before deploying)
  * JSON-LD schema and SEO fields
Usage: python3 forge_compile.py blueprint.json out_dir [--media media_map.json]
media_map.json: {"slot": {"id": 123, "url": "https://…/x.webp", "alt": "…", "width": 1600, "height": 900, "mime": "image/webp"}}
"""
import json, sys, os, re, html, random, string

HEX = string.hexdigits.lower()[:16]
def eid(): return ''.join(random.choice(HEX) for _ in range(7))
def esc(s): return html.escape(str(s or ''), quote=True)
def hexmix(c, white=0.9):
    c = c.lstrip('#'); r, g, b = int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)
    f = lambda v: int(round(v + (255 - v) * white)); return '#%02x%02x%02x' % (f(r), f(g), f(b))
def slug(s): return re.sub(r'[^a-z0-9]+', '-', str(s).lower()).strip('-')[:60]
def tel(s): return 'tel:' + re.sub(r'[^\d+]', '', str(s))
def num_from(v):
    m = re.search(r'[\d,\.]+', str(v)); return (float(m.group(0).replace(',', '')) if m else None)

class Forge:
    def __init__(self, bp, media):
        self.bp = bp; self.media = media or {}; self.page = bp['page']; self.site = bp.get('site', {}); self.brand = self.site.get('brand', {})
        self.primary = self.brand.get('primary', '#1d4e89'); self.accent = self.brand.get('accent', '#c9a227'); self.dark = self.brand.get('dark', '#111110')
        self.tint = hexmix(self.primary, 0.9); self.cta = self.page.get('cta', {}); self.warnings = []
        self.use_globals = self.brand.get('globals', True)  # False = write literal brand hex instead of Elementor Site Settings globals
    # ---------- media ----------
    def m(self, key):
        if not key: return None
        v = self.media.get(key) or (self.bp.get('media', {}).get(key) if isinstance(self.bp.get('media', {}).get(key), dict) and self.bp['media'][key].get('url') else None)
        if not v:
            spec = self.bp.get('media', {}).get(key, {}); msg = f'BLOCK: media slot "{key}" unresolved (source: {spec.get("source", "?")}) — placeholder used; run media-resolve before deploy'
            if msg not in self.warnings: self.warnings.append(msg)
            return {'id': 0, 'url': 'https://placehold.co/1600x900/e9e7e0/4f4e4a?text=' + key, 'alt': spec.get('alt', key), 'kind': spec.get('kind', 'image')}
        v = dict(v); v.setdefault('kind', self.bp.get('media', {}).get(key, {}).get('kind', 'image')); v.setdefault('alt', self.bp.get('media', {}).get(key, {}).get('alt', '')); return v
    # ---------- elementor primitives ----------
    def w(self, wtype, settings): return {'id': eid(), 'elType': 'widget', 'widgetType': wtype, 'settings': settings, 'elements': []}
    def c(self, elements, settings=None, inner=True):
        s = {'content_width': 'full', 'flex_direction': 'column', 'flex_gap': {'column': '16', 'row': '16', 'unit': 'px', 'size': 16}}
        if settings: s.update(settings)
        return {'id': eid(), 'elType': 'container', 'settings': s, 'elements': elements, 'isInner': inner}
    def section(self, elements, sec, extra=None):
        style = sec.get('style', 'light'); width = sec.get('width', 'boxed')
        s = {'content_width': 'boxed', 'boxed_width': {'unit': 'px', 'size': 1140 if width != 'narrow' else 820}, 'flex_direction': 'column',
             'flex_gap': {'column': '20', 'row': '20', 'unit': 'px', 'size': 20},
             'padding': {'unit': 'px', 'top': '72', 'right': '20', 'bottom': '72', 'left': '20', 'isLinked': False},
             'padding_mobile': {'unit': 'px', 'top': '44', 'right': '16', 'bottom': '44', 'left': '16', 'isLinked': False},
             '_element_id': sec.get('id') or slug(sec.get('heading') or sec.get('type')), 'css_classes': 'forge-section forge-sec-' + sec['type'], 'html_tag': 'section'}
        if style == 'tint': s.update({'background_background': 'classic', 'background_color': self.tint})
        elif style == 'dark': s.update({'background_background': 'classic', 'background_color': self.dark})
        elif style == 'brand': s.update({'background_background': 'classic', 'background_color': self.primary})
        if extra: s.update(extra)
        return {'id': eid(), 'elType': 'container', 'settings': s, 'elements': elements, 'isInner': False}
    def heading(self, text, tag='h2', align='left', color=None, size=None):
        s = {'title': text, 'header_size': tag, 'align': align}
        if color: s['title_color'] = color
        elif self.use_globals: s['__globals__'] = {'title_color': 'globals/colors?id=primary'}
        else: s['title_color'] = self.primary
        if size: s['size'] = size
        return self.w('heading', s)
    def text(self, html_, color=None):
        s = {'editor': html_}
        if color: s['text_color'] = color
        return self.w('text-editor', s)
    def button(self, label, url, kind='primary', align='left'):
        s = {'text': label, 'link': {'url': url, 'is_external': '', 'nofollow': '', 'custom_attributes': ''}, 'size': 'lg', 'align': align, 'button_type': 'default' if kind == 'primary' else 'info',
             'border_radius': {'unit': 'px', 'top': '8', 'right': '8', 'bottom': '8', 'left': '8', 'isLinked': True}, 'css_classes': 'forge-cta forge-cta-' + kind}
        if self.use_globals: s['__globals__'] = {'background_color': 'globals/colors?id=primary' if kind == 'primary' else 'globals/colors?id=accent', 'typography_typography': 'globals/typography?id=accent'}
        else: s.update({'background_color': self.primary if kind == 'primary' else self.accent, 'button_text_color': '#ffffff' if kind == 'primary' else '#111111'})
        if url.startswith('tel:'): s['selected_icon'] = {'value': 'fas fa-phone', 'library': 'fa-solid'}
        return self.w('button', s)
    def image(self, media, size='large'):
        return self.w('image', {'image': {'url': media['url'], 'id': media.get('id', 0), 'alt': media.get('alt', ''), 'source': 'library' if media.get('id') else 'url'}, 'image_size': size, 'caption_source': 'none', 'link_to': 'none', 'align': 'center'})
    def video(self, media, poster=None):
        url = media['url']; s = {'lazy_load': 'yes', 'play_on_mobile': 'yes', 'controls': 'yes'}
        if 'youtube.com' in url or 'youtu.be' in url: s.update({'video_type': 'youtube', 'youtube_url': url, 'yt_privacy': 'yes', 'rel': ''})
        elif 'vimeo.com' in url: s.update({'video_type': 'vimeo', 'vimeo_url': url})
        else:
            s['video_type'] = 'hosted'
            if media.get('id'): s['hosted_url'] = {'url': url, 'id': media['id']}
            else: s.update({'insert_url': 'yes', 'external_url': {'url': url}})
        if poster: s.update({'show_image_overlay': 'yes', 'image_overlay': {'url': poster['url'], 'id': poster.get('id', 0)}, 'show_play_icon': 'yes'})
        return self.w('video', s)
    def cta_buttons(self, keys, align='left'):
        els = []
        for k in keys or []:
            cta = self.cta.get(k) if isinstance(k, str) else k
            if not cta: continue
            if cta.get('url'): els.append(self.button(cta['label'], cta['url'], 'primary' if k == 'primary' else 'secondary', align))
            if cta.get('phone'): els.append(self.button(cta.get('phone_label', 'Call ' + cta['phone']), tel(cta['phone']), 'secondary', align))
        return self.c(els, {'flex_direction': 'row', 'flex_wrap': 'wrap', 'flex_gap': {'column': '12', 'row': '12', 'unit': 'px', 'size': 12}, 'flex_justify_content': 'flex-start' if align == 'left' else 'center'}) if els else None
    def icon_list(self, items, icon='fas fa-check'):
        return self.w('icon-list', {'icon_list': [{'text': t, 'selected_icon': {'value': icon, 'library': 'fa-solid'}, '_id': eid()} for t in items], 'view': 'traditional', 'space_between': {'unit': 'px', 'size': 8}})
    # ---------- sections ----------
    def s_hero(self, sec):
        pg = self.page; left = []
        if sec.get('eyebrow'): left.append(self.heading(sec['eyebrow'], 'h6', color=self.accent))
        left.append(self.heading(sec.get('h1') or pg['h1'], 'h1'))
        if sec.get('lede'): left.append(self.text('<p class="forge-lede">' + esc(sec['lede']) + '</p>'))
        b = self.cta_buttons(sec.get('cta', ['primary']));  left.append(b) if b else None
        if sec.get('trust', True) and pg.get('conversion', {}).get('trust'): left.append(self.icon_list(pg['conversion']['trust']))
        media = self.m(sec.get('media')) if sec.get('media') else None
        layout = sec.get('layout', 'split' if media else 'center')
        if layout == 'split' and media:
            right = [self.video(media, self.m(sec.get('poster')) if sec.get('poster') else None) if media.get('kind') == 'video' else self.image(media, 'full')]
            row = self.c([self.c(left, {'width': {'unit': '%', 'size': 55}, 'width_mobile': {'unit': '%', 'size': 100}, 'flex_justify_content': 'center'}),
                          self.c(right, {'width': {'unit': '%', 'size': 45}, 'width_mobile': {'unit': '%', 'size': 100}})],
                         {'flex_direction': 'row', 'flex_direction_mobile': 'column', 'flex_align_items': 'center', 'flex_gap': {'column': '40', 'row': '24', 'unit': 'px', 'size': 40}})
            return self.section([row], sec, {'min_height': {'unit': 'vh', 'size': 60}, 'flex_justify_content': 'center'})
        if layout == 'cover' and media and media.get('kind') != 'video':
            for el in left:
                if el['elType'] == 'widget' and el['widgetType'] in ('heading', 'text-editor'): el['settings'].pop('__globals__', None); el['settings'][ 'title_color' if el['widgetType'] == 'heading' else 'text_color'] = '#ffffff'
            return self.section([self.c(left, {'width': {'unit': '%', 'size': 66}, 'width_mobile': {'unit': '%', 'size': 100}})], sec,
                                {'background_background': 'classic', 'background_image': {'url': media['url'], 'id': media.get('id', 0)}, 'background_size': 'cover', 'background_position': 'center center',
                                 'background_overlay_background': 'classic', 'background_overlay_color': self.dark, 'background_overlay_opacity': {'unit': 'px', 'size': 0.62}, 'min_height': {'unit': 'vh', 'size': 70}, 'flex_justify_content': 'center'})
        for el in left:
            if el['elType'] == 'widget' and 'align' in el['settings']: el['settings']['align'] = 'center'
        return self.section([self.c(left, {'width': {'unit': '%', 'size': 80}, 'width_mobile': {'unit': '%', 'size': 100}, 'flex_align_items': 'center'})], sec, {'flex_align_items': 'center'})
    def s_answer(self, sec):
        return self.section([self.heading(sec.get('heading') or 'The short answer', 'h2'), self.text('<p class="forge-answer"><strong>' + esc(sec['body']) + '</strong></p>')], dict(sec, style=sec.get('style', 'tint'), width='narrow'))
    def s_key_facts(self, sec):
        cards = [self.c([self.heading(it['value'], 'h3', color=self.primary, size='xl'), self.text('<p>' + esc(it['label']) + (f'<br><small>{esc(it["source"])}</small>' if it.get('source') else '') + '</p>')],
                        {'width': {'unit': '%', 'size': max(22, 100 // max(1, min(4, len(sec['items'])))) - 2}, 'width_mobile': {'unit': '%', 'size': 100}, 'background_background': 'classic', 'background_color': '#ffffff',
                         'border_radius': {'unit': 'px', 'top': '12', 'right': '12', 'bottom': '12', 'left': '12', 'isLinked': True}, 'padding': {'unit': 'px', 'top': '22', 'right': '22', 'bottom': '22', 'left': '22', 'isLinked': True}}) for it in sec['items']]
        els = ([self.heading(sec['heading'], 'h2')] if sec.get('heading') else []) + [self.c(cards, {'flex_direction': 'row', 'flex_wrap': 'wrap', 'flex_gap': {'column': '16', 'row': '16', 'unit': 'px', 'size': 16}})]
        return self.section(els, dict(sec, style=sec.get('style', 'tint')))
    def s_rich_text(self, sec):
        els = ([self.heading(sec['heading'], sec.get('tag', 'h2'))] if sec.get('heading') else []) + [self.text(sec['html'])]
        return self.section(els, dict(sec, width=sec.get('width', 'narrow')))
    def s_steps(self, sec):
        items = [self.c([self.heading(f"{i+1}. {st['title']}", 'h3'), self.text('<p>' + esc(st['text']) + '</p>')],
                        {'width': {'unit': '%', 'size': 100}}) for i, st in enumerate(sec['steps'])]
        return self.section([self.heading(sec.get('heading', 'How it works'), 'h2')] + items, dict(sec, width='narrow'))
    def s_features(self, sec):
        cols = min(3, max(1, len(sec['items']))); cards = []
        for it in sec['items']:
            els = [self.heading(it['title'], 'h3', size='medium'), self.text('<p>' + esc(it['text']) + (f' <a href="{esc(it["url"])}">{esc(it.get("link", "Learn more"))}</a>' if it.get('url') else '') + '</p>')]
            if it.get('icon'): els.insert(0, self.w('icon', {'selected_icon': {'value': it['icon'], 'library': 'fa-solid'}, 'view': 'default', 'align': 'left', 'size': {'unit': 'px', 'size': 34}, 'primary_color': self.primary}))
            cards.append(self.c(els, {'width': {'unit': '%', 'size': (100 // cols) - 2}, 'width_mobile': {'unit': '%', 'size': 100}}))
        return self.section([self.heading(sec['heading'], 'h2')] + ([self.text('<p>' + esc(sec['text']) + '</p>')] if sec.get('text') else []) + [self.c(cards, {'flex_direction': 'row', 'flex_wrap': 'wrap', 'flex_gap': {'column': '28', 'row': '28', 'unit': 'px', 'size': 28}})], sec)
    def s_media(self, sec):
        md = self.m(sec['media']); w = self.video(md, self.m(sec.get('poster')) if sec.get('poster') else None) if md.get('kind') == 'video' else self.image(md, 'full')
        els = ([self.heading(sec['heading'], 'h2')] if sec.get('heading') else []) + [w] + ([self.text('<p><small>' + esc(sec['caption']) + '</small></p>')] if sec.get('caption') else [])
        return self.section(els, dict(sec, width=sec.get('width', 'boxed')))
    def s_video(self, sec):
        md = self.m(sec['media']); els = ([self.heading(sec['heading'], 'h2')] if sec.get('heading') else []) + [self.video(md, self.m(sec.get('poster')) if sec.get('poster') else None)]
        if sec.get('transcript'): els.append(self.w('accordion', {'tabs': [{'tab_title': 'Video transcript', 'tab_content': '<p>' + esc(sec['transcript']) + '</p>', '_id': eid()}], 'faq_schema': ''}))
        return self.section(els, dict(sec, width='narrow'))
    def s_gallery(self, sec):
        cols = sec.get('columns', 3); imgs = [self.c([self.image(self.m(k), 'medium_large')], {'width': {'unit': '%', 'size': (100 // cols) - 2}, 'width_mobile': {'unit': '%', 'size': 50}}) for k in sec['media']]
        return self.section(([self.heading(sec['heading'], 'h2')] if sec.get('heading') else []) + [self.c(imgs, {'flex_direction': 'row', 'flex_wrap': 'wrap', 'flex_gap': {'column': '12', 'row': '12', 'unit': 'px', 'size': 12}})], sec)
    def s_testimonials(self, sec):
        cards = []
        for it in sec['items']:
            els = []
            if it.get('rating'): els.append(self.w('star-rating', {'rating': it['rating'], 'star_style': 'star_fontawesome', 'align': 'left', 'stars_color': self.accent}))
            ts = {'testimonial_content': it['quote'], 'testimonial_name': it.get('name', ''), 'testimonial_job': it.get('role', ''), 'testimonial_alignment': 'left', 'testimonial_image_position': 'aside'}
            if it.get('media'): md = self.m(it['media']); ts['testimonial_image'] = {'url': md['url'], 'id': md.get('id', 0)}
            els.append(self.w('testimonial', ts))
            cards.append(self.c(els, {'width': {'unit': '%', 'size': (100 // min(3, len(sec['items']))) - 2}, 'width_mobile': {'unit': '%', 'size': 100}, 'background_background': 'classic', 'background_color': '#ffffff', 'padding': {'unit': 'px', 'top': '22', 'right': '22', 'bottom': '22', 'left': '22', 'isLinked': True}, 'border_radius': {'unit': 'px', 'top': '12', 'right': '12', 'bottom': '12', 'left': '12', 'isLinked': True}}))
        return self.section([self.heading(sec.get('heading', 'What clients say'), 'h2'), self.c(cards, {'flex_direction': 'row', 'flex_wrap': 'wrap', 'flex_gap': {'column': '20', 'row': '20', 'unit': 'px', 'size': 20}})], dict(sec, style=sec.get('style', 'tint')))
    def s_stats(self, sec):
        cards = []
        for it in sec['items']:
            n = num_from(it['value'])
            if n is not None:
                m = re.match(r'^([^\d]*)([\d,\.]+)(.*)$', str(it['value']).strip())
                cards.append(self.c([self.w('counter', {'starting_number': 0, 'ending_number': int(n) if n == int(n) else n, 'prefix': m.group(1) if m else '', 'suffix': m.group(3) if m else '', 'title': it['label'], 'thousand_separator': 'yes', 'title_tag': 'div'})], {'width': {'unit': '%', 'size': (100 // min(4, len(sec['items']))) - 2}, 'width_mobile': {'unit': '%', 'size': 50}}))
            else: cards.append(self.c([self.heading(it['value'], 'h3', align='center'), self.text('<p style="text-align:center">' + esc(it['label']) + '</p>')], {'width': {'unit': '%', 'size': (100 // min(4, len(sec['items']))) - 2}, 'width_mobile': {'unit': '%', 'size': 50}}))
        return self.section(([self.heading(sec['heading'], 'h2', align='center')] if sec.get('heading') else []) + [self.c(cards, {'flex_direction': 'row', 'flex_wrap': 'wrap', 'flex_gap': {'column': '16', 'row': '16', 'unit': 'px', 'size': 16}})], dict(sec, style=sec.get('style', 'brand')))
    def s_faq(self, sec):
        acc = self.w('accordion', {'tabs': [{'tab_title': it['q'], 'tab_content': '<p>' + esc(it['a']) + '</p>', '_id': eid()} for it in sec['items']], 'faq_schema': '', 'title_html_tag': 'h3', 'selected_icon': {'value': 'fas fa-plus', 'library': 'fa-solid'}, 'selected_active_icon': {'value': 'fas fa-minus', 'library': 'fa-solid'}})
        return self.section([self.heading(sec.get('heading', 'Frequently asked questions'), 'h2'), acc], dict(sec, width='narrow'))
    def s_cta_band(self, sec):
        els = [self.heading(sec['heading'], 'h2', align='center', color='#ffffff')]
        if sec.get('text'): els.append(self.text('<p style="text-align:center">' + esc(sec['text']) + '</p>', color='#ffffff'))
        b = self.cta_buttons(sec.get('cta', ['primary']), 'center'); els.append(b) if b else None
        if b:
            for el in b['elements']:
                if self.use_globals: el['settings']['__globals__'] = {'background_color': 'globals/colors?id=accent', 'typography_typography': 'globals/typography?id=accent'}
                else: el['settings'].update({'background_color': self.accent, 'button_text_color': '#111111'})
        return self.section(els, dict(sec, style='brand'), {'flex_align_items': 'center'})
    def s_form(self, sec):
        conv = self.page.get('conversion', {}); f = conv.get('form', {}); prov = f.get('provider', 'html'); els = []
        if sec.get('heading'): els.append(self.heading(sec['heading'], 'h2'))
        if sec.get('text'): els.append(self.text('<p>' + esc(sec['text']) + '</p>'))
        fields = f.get('fields') or [{'id': 'name', 'label': 'Full name', 'type': 'text', 'required': True}, {'id': 'phone', 'label': 'Phone', 'type': 'tel', 'required': True}, {'id': 'email', 'label': 'Email', 'type': 'email', 'required': True}, {'id': 'message', 'label': 'Tell us what happened', 'type': 'textarea', 'required': False}]
        consent = f.get('consent', 'By submitting, you agree to be contacted by phone, text or email about your request. Message and data rates may apply. Submitting does not create a client relationship.')
        if prov == 'elementor_pro':
            ff = [{'custom_id': x['id'], 'field_label': x['label'], 'field_type': x['type'], 'required': 'true' if x.get('required') else '', 'placeholder': x.get('placeholder', ''), 'width': '100', '_id': eid()} for x in fields]
            ff.append({'custom_id': 'consent', 'field_label': consent, 'field_type': 'acceptance', 'required': 'true', 'width': '100', '_id': eid()})
            els.append(self.w('form', {'form_name': f.get('name', 'Lead form'), 'form_fields': ff, 'button_text': f.get('button', 'Send my request'), 'button_size': 'md', 'submit_actions': ['email'], 'email_to': f.get('email_to', ''), 'email_subject': 'New lead: ' + self.page.get('h1', ''), 'success_message': f.get('success', 'Thanks — we will contact you shortly.'), 'form_id': slug(self.page['slug']) + '-form'}))
        elif prov in ('wpforms', 'gravity', 'cf7', 'fluent', 'shortcode') and f.get('shortcode'):
            els.append(self.w('shortcode', {'shortcode': f['shortcode']}))
        else:
            els.append(self.w('html', {'html': self.html_form()}))
        return self.section(els, dict(sec, width='narrow', style=sec.get('style', 'tint')), {'_element_id': sec.get('id', 'contact')})
    def s_map(self, sec):
        els = ([self.heading(sec['heading'], 'h2')] if sec.get('heading') else []) + [self.w('google_maps', {'address': sec['address'], 'zoom': {'unit': 'px', 'size': 14}, 'height': {'unit': 'px', 'size': 360}})]
        if sec.get('text'): els.append(self.text('<p>' + esc(sec['text']) + '</p>'))
        return self.section(els, sec)
    def s_table(self, sec):
        th = ''.join(f'<th scope="col">{esc(c)}</th>' for c in sec['columns']); tr = ''.join('<tr>' + ''.join(f'<td>{esc(v)}</td>' for v in r) + '</tr>' for r in sec['rows'])
        return self.section(([self.heading(sec['heading'], 'h2')] if sec.get('heading') else []) + [self.w('html', {'html': f'<div class="forge-tablewrap"><table class="forge-table"><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table></div>'})], sec)
    def s_authors(self, sec):
        a = self.page.get('author', {}); els = [self.heading(sec.get('heading', 'Reviewed by'), 'h2')]
        row = []
        if a.get('media'): row.append(self.c([self.image(self.m(a['media']), 'thumbnail')], {'width': {'unit': '%', 'size': 18}, 'width_mobile': {'unit': '%', 'size': 40}}))
        row.append(self.c([self.text(f'<p><strong>{esc(a.get("name", ""))}</strong>{(", " + esc(a["credentials"])) if a.get("credentials") else ""}<br>{esc(a.get("bio", sec.get("text", "")))}' + (f'<br><a href="{esc(a["url"])}">Profile</a>' if a.get('url') else '') + '</p>')], {'width': {'unit': '%', 'size': 80}, 'width_mobile': {'unit': '%', 'size': 100}}))
        els.append(self.c(row, {'flex_direction': 'row', 'flex_align_items': 'center', 'flex_gap': {'column': '20', 'row': '12', 'unit': 'px', 'size': 20}}))
        return self.section(els, dict(sec, width='narrow'))
    def s_links(self, sec):
        items = sec.get('items') or self.page.get('internal_links', [])
        lst = self.w('icon-list', {'icon_list': [{'text': it['anchor'], 'link': {'url': it['url'], 'is_external': ''}, 'selected_icon': {'value': 'fas fa-arrow-right', 'library': 'fa-solid'}, '_id': eid()} for it in items], 'view': 'traditional'})
        return self.section([self.heading(sec.get('heading', 'Related'), 'h2'), lst], dict(sec, width='narrow'))
    def s_html(self, sec): return self.section([self.w('html', {'html': sec['html']})], sec)
    def sticky_bar(self):
        p = self.cta.get('primary', {}); tl = tel(p['phone']) if p.get('phone') else None
        a = (f'<a class="forge-sticky-call" href="{esc(tl)}">Call now</a>' if tl else '') + (f'<a class="forge-sticky-cta" href="{esc(p.get("url", "#contact"))}">{esc(p.get("label", "Get started"))}</a>' if p else '')
        css = f'<style>.forge-sticky{{display:none}}@media(max-width:767px){{.forge-sticky{{display:flex;position:fixed;left:0;right:0;bottom:0;z-index:9999;gap:8px;padding:10px 12px;background:#fff;box-shadow:0 -4px 16px rgba(0,0,0,.14)}}.forge-sticky a{{flex:1;text-align:center;padding:12px;border-radius:8px;font-weight:700;text-decoration:none}}.forge-sticky-call{{background:{self.accent};color:#111}}.forge-sticky-cta{{background:{self.primary};color:#fff}}body{{padding-bottom:70px}}}}</style>'
        return {'id': eid(), 'elType': 'container', 'settings': {'content_width': 'full', 'padding': {'unit': 'px', 'top': '0', 'right': '0', 'bottom': '0', 'left': '0', 'isLinked': True}, 'css_classes': 'forge-sticky-wrap'}, 'elements': [self.w('html', {'html': css + '<div class="forge-sticky">' + a + '</div>'})], 'isInner': False}
    # ---------- drivers ----------
    def elementor(self):
        out = []
        for sec in self.bp['sections']:
            fn = getattr(self, 's_' + sec['type'], None)
            if not fn: self.warnings.append(f'unknown section type {sec["type"]} skipped'); continue
            out.append(fn(sec))
        if self.page.get('conversion', {}).get('sticky_mobile_bar', True) and self.cta.get('primary'): out.append(self.sticky_bar())
        return out
    def page_settings(self):
        ps = {'hide_title': 'yes', 'template': self.page.get('template', 'default')}
        if self.page.get('custom_css'): ps['custom_css'] = self.page['custom_css']
        return ps
    def template_file(self, content):
        return {'content': content, 'page_settings': self.page_settings(), 'version': '0.4', 'title': self.page.get('title') or self.page['h1'], 'type': 'page'}
    # ---------- semantic html (post_content, headless fallback, preview) ----------
    def html(self):
        pg = self.page; out = []
        for sec in self.bp['sections']:
            t = sec['type']; sid = sec.get('id') or slug(sec.get('heading') or t); h = lambda tag, s, cls='': f'<{tag}{(" class=" + chr(34) + cls + chr(34)) if cls else ""}>{esc(s)}</{tag}>'
            body = ''
            if t == 'hero':
                md = self.m(sec['media']) if sec.get('media') else None
                body = (h('p', sec['eyebrow'], 'forge-eyebrow') if sec.get('eyebrow') else '') + h('h1', sec.get('h1') or pg['h1']) + (h('p', sec['lede'], 'forge-lede') if sec.get('lede') else '') + self.html_ctas(sec.get('cta', ['primary']))
                if sec.get('trust', True) and pg.get('conversion', {}).get('trust'): body += '<ul class="forge-trust">' + ''.join(h('li', x) for x in pg['conversion']['trust']) + '</ul>'
                if md: body = f'<div class="forge-split"><div>{body}</div><div>{self.html_media(md, True)}</div></div>'
            elif t == 'answer': body = h('h2', sec.get('heading') or 'The short answer') + f'<p class="forge-answer"><strong>{esc(sec["body"])}</strong></p>'
            elif t == 'key_facts': body = (h('h2', sec['heading']) if sec.get('heading') else '') + '<dl class="forge-facts">' + ''.join(f'<div><dt>{esc(i["value"])}</dt><dd>{esc(i["label"])}' + (f' <small>({esc(i["source"])})</small>' if i.get('source') else '') + '</dd></div>' for i in sec['items']) + '</dl>'
            elif t == 'rich_text': body = (h(sec.get('tag', 'h2'), sec['heading']) if sec.get('heading') else '') + sec['html']
            elif t == 'steps': body = h('h2', sec.get('heading', 'How it works')) + '<ol class="forge-steps">' + ''.join(f'<li><h3>{esc(s["title"])}</h3><p>{esc(s["text"])}</p></li>' for s in sec['steps']) + '</ol>'
            elif t == 'features': body = h('h2', sec['heading']) + (h('p', sec['text']) if sec.get('text') else '') + '<div class="forge-grid">' + ''.join(f'<div class="forge-card"><h3>{(chr(60) + "a href=" + chr(34) + esc(i["url"]) + chr(34) + chr(62) + esc(i["title"]) + chr(60) + "/a" + chr(62)) if i.get("url") else esc(i["title"])}</h3><p>{esc(i["text"])}</p></div>' for i in sec['items']) + '</div>'
            elif t == 'media': body = (h('h2', sec['heading']) if sec.get('heading') else '') + self.html_media(self.m(sec['media'])) + (f'<p><small>{esc(sec["caption"])}</small></p>' if sec.get('caption') else '')
            elif t == 'video': body = (h('h2', sec['heading']) if sec.get('heading') else '') + self.html_media(self.m(sec['media'])) + (f'<details><summary>Video transcript</summary><p>{esc(sec["transcript"])}</p></details>' if sec.get('transcript') else '')
            elif t == 'gallery': body = (h('h2', sec['heading']) if sec.get('heading') else '') + '<div class="forge-grid">' + ''.join(self.html_media(self.m(k)) for k in sec['media']) + '</div>'
            elif t == 'testimonials': body = h('h2', sec.get('heading', 'What clients say')) + '<div class="forge-grid">' + ''.join(f'<blockquote class="forge-card"><p>{esc(i["quote"])}</p><footer>{esc(i.get("name", ""))}{(" — " + esc(i["role"])) if i.get("role") else ""}{(" · " + str(i["rating"]) + "/5") if i.get("rating") else ""}</footer></blockquote>' for i in sec['items']) + '</div>'
            elif t == 'stats': body = (h('h2', sec['heading']) if sec.get('heading') else '') + '<dl class="forge-facts forge-stats">' + ''.join(f'<div><dt>{esc(i["value"])}</dt><dd>{esc(i["label"])}</dd></div>' for i in sec['items']) + '</dl>'
            elif t == 'faq': body = h('h2', sec.get('heading', 'Frequently asked questions')) + ''.join(f'<details class="forge-faq"><summary><h3>{esc(i["q"])}</h3></summary><p>{esc(i["a"])}</p></details>' for i in sec['items'])
            elif t == 'cta_band': body = h('h2', sec['heading']) + (h('p', sec['text']) if sec.get('text') else '') + self.html_ctas(sec.get('cta', ['primary']))
            elif t == 'form': body = (h('h2', sec['heading']) if sec.get('heading') else '') + (h('p', sec['text']) if sec.get('text') else '') + self.html_form()
            elif t == 'map': body = (h('h2', sec['heading']) if sec.get('heading') else '') + f'<p class="forge-address">{esc(sec["address"])}</p>' + (h('p', sec['text']) if sec.get('text') else '')
            elif t == 'table': body = (h('h2', sec['heading']) if sec.get('heading') else '') + '<div class="forge-tablewrap"><table class="forge-table"><thead><tr>' + ''.join(f'<th scope="col">{esc(c)}</th>' for c in sec['columns']) + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join(f'<td>{esc(v)}</td>' for v in r) + '</tr>' for r in sec['rows']) + '</tbody></table></div>'
            elif t == 'authors':
                a = pg.get('author', {}); body = h('h2', sec.get('heading', 'Reviewed by')) + f'<p class="forge-author"><strong>{esc(a.get("name", ""))}</strong>{(", " + esc(a["credentials"])) if a.get("credentials") else ""}<br>{esc(a.get("bio", sec.get("text", "")))}' + (f' <a href="{esc(a["url"])}">Profile</a>' if a.get('url') else '') + '</p>'
            elif t == 'links': items = sec.get('items') or pg.get('internal_links', []); body = h('h2', sec.get('heading', 'Related')) + '<ul class="forge-links">' + ''.join(f'<li><a href="{esc(i["url"])}">{esc(i["anchor"])}</a></li>' for i in items) + '</ul>'
            elif t == 'html': body = sec['html']
            out.append(f'<section id="{esc(sid)}" class="forge-section forge-sec-{t} forge-{sec.get("style", "light")}"><div class="forge-inner{" forge-narrow" if sec.get("width") == "narrow" else ""}">{body}</div></section>')
        return '\n'.join(out)
    def html_ctas(self, keys):
        a = ''
        for k in keys or []:
            cta = self.cta.get(k) if isinstance(k, str) else k
            if not cta: continue
            if cta.get('url'): a += f'<a class="forge-btn forge-btn-{k if isinstance(k, str) else "primary"}" href="{esc(cta["url"])}">{esc(cta["label"])}</a> '
            if cta.get('phone'): a += f'<a class="forge-btn forge-btn-secondary" href="{esc(tel(cta["phone"]))}">{esc(cta.get("phone_label", "Call " + cta["phone"]))}</a> '
        return f'<p class="forge-ctas">{a}</p>' if a else ''
    def html_media(self, md, priority=False):
        if md.get('kind') == 'video':
            u = md['url']
            if 'youtube.com' in u or 'youtu.be' in u:
                vid = re.search(r'(?:v=|youtu\.be/|embed/)([\w-]{6,})', u); vid = vid.group(1) if vid else ''
                return f'<div class="forge-video"><iframe loading="lazy" src="https://www.youtube-nocookie.com/embed/{vid}" title="{esc(md.get("alt", "Video"))}" allow="accelerometer; autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe></div>'
            return f'<video controls preload="metadata" playsinline{(" poster=" + chr(34) + esc(md["poster"]) + chr(34)) if md.get("poster") else ""}><source src="{esc(u)}" type="{esc(md.get("mime", "video/mp4"))}">{esc(md.get("alt", ""))}</video>'
        wh = f' width="{md["width"]}" height="{md["height"]}"' if md.get('width') and md.get('height') else ''
        return f'<img src="{esc(md["url"])}" alt="{esc(md.get("alt", ""))}"{wh}{"" if priority else " loading=" + chr(34) + "lazy" + chr(34)}{" fetchpriority=" + chr(34) + "high" + chr(34) if priority else ""} decoding="async">'
    def html_form(self):
        f = self.page.get('conversion', {}).get('form', {}); fields = f.get('fields') or [{'id': 'name', 'label': 'Full name', 'type': 'text', 'required': True}, {'id': 'phone', 'label': 'Phone', 'type': 'tel', 'required': True}, {'id': 'email', 'label': 'Email', 'type': 'email', 'required': True}, {'id': 'message', 'label': 'Tell us what happened', 'type': 'textarea', 'required': False}]
        if f.get('shortcode'): return f['shortcode']
        consent = f.get('consent', 'By submitting, you agree to be contacted by phone, text or email about your request. Message and data rates may apply. Submitting does not create a client relationship.')
        rows = ''.join(f'<label>{esc(x["label"])}' + (f'<textarea name="{esc(x["id"])}"{" required" if x.get("required") else ""}></textarea>' if x['type'] == 'textarea' else f'<input type="{esc(x["type"])}" name="{esc(x["id"])}"{" required" if x.get("required") else ""}>') + '</label>' for x in fields)
        return f'<form class="forge-form" method="post" action="{esc(f.get("action", "/wp-json/forge/v1/lead"))}" data-forge-form><input type="hidden" name="page" value="{esc(self.page["slug"])}"><input type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px">{rows}<label class="forge-consent"><input type="checkbox" name="consent" value="yes" required> {esc(consent)}</label><button type="submit" class="forge-btn forge-btn-primary">{esc(f.get("button", "Send my request"))}</button><p class="forge-form-msg" aria-live="polite"></p></form>' + FORM_JS
    # ---------- schema ----------
    def schema(self):
        pg = self.page; site = self.site; base = site.get('url', '').rstrip('/'); url = pg.get('canonical') or f"{base}/{pg['slug'].strip('/')}/"
        ent = pg.get('entity') or {}; org = dict(ent) if ent else {'@type': 'Organization', 'name': self.brand.get('name', site.get('name', ''))}
        org.setdefault('@type', 'Organization'); org.setdefault('url', base + '/'); org['@id'] = base + '/#organization'
        if self.brand.get('logo_url'): org['logo'] = self.brand['logo_url']
        graph = [org]
        web = {'@type': 'WebPage', '@id': url + '#webpage', 'url': url, 'name': pg.get('title') or pg['h1'], 'description': pg.get('meta_description', ''), 'inLanguage': pg.get('language', 'en-US'), 'isPartOf': {'@id': base + '/#website'}, 'about': {'@id': org['@id']}}
        d = pg.get('dates', {})
        if d.get('published'): web['datePublished'] = d['published']
        if d.get('modified'): web['dateModified'] = d['modified']
        hero = next((s for s in self.bp['sections'] if s['type'] == 'hero' and s.get('media')), None)
        if hero: md = self.m(hero['media']); web['primaryImageOfPage'] = {'@type': 'ImageObject', 'url': md['url']}
        ans = next((s for s in self.bp['sections'] if s['type'] == 'answer'), None)
        if ans: web['speakable'] = {'@type': 'SpeakableSpecification', 'cssSelector': ['.forge-answer', 'h1']}
        if pg.get('author'):
            a = pg['author']; per = {'@type': 'Person', 'name': a['name']}
            if a.get('url'): per['url'] = a['url']
            if a.get('credentials'): per['jobTitle'] = a['credentials']
            web['reviewedBy'] = per; graph.append(per)
        graph.append(web)
        graph.append({'@type': 'WebSite', '@id': base + '/#website', 'url': base + '/', 'name': self.brand.get('name', site.get('name', '')), 'publisher': {'@id': org['@id']}})
        if pg.get('breadcrumbs'): graph.append({'@type': 'BreadcrumbList', 'itemListElement': [{'@type': 'ListItem', 'position': i + 1, 'name': b['name'], 'item': (base + b['url']) if b['url'].startswith('/') else b['url']} for i, b in enumerate(pg['breadcrumbs'] + [{'name': pg['h1'], 'url': url}])]})
        faq = next((s for s in self.bp['sections'] if s['type'] == 'faq'), None)
        if faq: graph.append({'@type': 'FAQPage', 'mainEntity': [{'@type': 'Question', 'name': i['q'], 'acceptedAnswer': {'@type': 'Answer', 'text': i['a']}} for i in faq['items']]})
        steps = next((s for s in self.bp['sections'] if s['type'] == 'steps' and s.get('howto')), None)
        if steps: graph.append({'@type': 'HowTo', 'name': steps.get('heading', pg['h1']), 'step': [{'@type': 'HowToStep', 'name': st['title'], 'text': st['text']} for st in steps['steps']]})
        if pg.get('archetype') in ('service', 'practice', 'location') and pg.get('service'):
            sv = dict(pg['service']); sv.setdefault('@type', 'Service'); sv.setdefault('name', pg['h1']); sv['provider'] = {'@id': org['@id']}; sv.setdefault('url', url); graph.append(sv)
        if pg.get('archetype') == 'article':
            art = {'@type': 'Article', 'headline': pg['h1'], 'mainEntityOfPage': {'@id': url + '#webpage'}, 'publisher': {'@id': org['@id']}}
            if pg.get('author'): art['author'] = {'@type': 'Person', 'name': pg['author']['name']}
            art.update({k: v for k, v in [('datePublished', d.get('published')), ('dateModified', d.get('modified'))] if v}); graph.append(art)
        web_vid = next((s for s in self.bp['sections'] if s['type'] == 'video'), None)
        if web_vid:
            md = self.m(web_vid['media']); vo = {'@type': 'VideoObject', 'name': web_vid.get('heading', pg['h1']), 'description': web_vid.get('description', pg.get('meta_description', '')), 'uploadDate': d.get('published', ''), 'contentUrl' if not ('youtube' in md['url'] or 'vimeo' in md['url']) else 'embedUrl': md['url']}
            if web_vid.get('poster'): vo['thumbnailUrl'] = self.m(web_vid['poster'])['url']
            if web_vid.get('transcript'): vo['transcript'] = web_vid['transcript']
            graph.append(vo)
        graph.extend(pg.get('schema_extra', []))
        return {'@context': 'https://schema.org', '@graph': graph}
    def seo(self):
        pg = self.page; return {'title': pg.get('title') or pg['h1'], 'description': pg.get('meta_description', ''), 'canonical': pg.get('canonical', ''), 'noindex': bool(pg.get('noindex')), 'og_image': (self.m(next((s['media'] for s in self.bp['sections'] if s['type'] == 'hero' and s.get('media')), None)) or {}).get('url', '')}
    def lint(self):
        pg = self.page; w = []
        if len(pg.get('title', '')) > 60: w.append(f'title {len(pg["title"])} chars (aim ≤ 60)')
        if not 70 <= len(pg.get('meta_description', '')) <= 160: w.append(f'meta description {len(pg.get("meta_description", ""))} chars (aim 120–158)')
        if not any(s['type'] == 'answer' for s in self.bp['sections']): w.append('no answer capsule (AI-citable direct answer) — add an "answer" section right after the hero')
        if not any(s['type'] == 'faq' for s in self.bp['sections']): w.append('no FAQ section — add 4–8 real questions')
        if sum(1 for s in self.bp['sections'] if s['type'] == 'hero') != 1: w.append('exactly one hero required')
        h1s = [s for s in self.bp['sections'] if s['type'] == 'hero']
        if h1s and len((h1s[0].get('h1') or pg['h1'])) > 70: w.append('H1 over 70 chars')
        for k, spec in self.bp.get('media', {}).items():
            if not spec.get('alt'): w.append(f'media "{k}" has no alt text')
        if not pg.get('cta', {}).get('primary'): w.append('no primary CTA')
        if not pg.get('internal_links'): w.append('no internal links declared (verify each against the live sitemap before adding)')
        blob = json.dumps(self.bp, ensure_ascii=False).lower()
        for bad in ('[[verify', 'lorem ipsum', 'todo:', 'xxx', 'placeholder text'):
            if bad in blob: w.append(f'BLOCK: "{bad}" found in the blueprint — resolve before deploy')
        return w + self.warnings

FORM_JS = '<script>(function(){var f=document.querySelector("[data-forge-form]");if(!f)return;f.addEventListener("submit",function(e){e.preventDefault();var m=f.querySelector(".forge-form-msg"),b=f.querySelector("button");b.disabled=true;var d={};new FormData(f).forEach(function(v,k){d[k]=v});fetch(f.action,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(d)}).then(function(r){return r.json()}).then(function(j){m.textContent=j.message||"Thanks — we will be in touch.";if(j.ok!==false){f.reset();if(window.dataLayer)window.dataLayer.push({event:"forge_lead",page:d.page});}b.disabled=false}).catch(function(){m.textContent="Something went wrong — please call us.";b.disabled=false})})})();</script>'

PREVIEW_CSS = ''':root{--p:%(p)s;--a:%(a)s;--t:%(t)s;--d:%(d)s}*{box-sizing:border-box}body{margin:0;font:16px/1.6 %(font)s;color:#1b1b1a;background:#fff}h1,h2,h3{font-family:%(hfont)s;line-height:1.15;margin:.2em 0 .5em}h1{font-size:clamp(30px,4.2vw,48px)}h2{font-size:clamp(24px,3vw,34px)}h3{font-size:20px}.forge-section{padding:72px 20px}.forge-tint{background:var(--t)}.forge-brand{background:var(--p);color:#fff}.forge-brand h2{color:#fff}.forge-dark{background:var(--d);color:#fff}.forge-inner{max-width:1140px;margin:0 auto}.forge-narrow{max-width:820px}.forge-split{display:grid;grid-template-columns:1.2fr 1fr;gap:40px;align-items:center}.forge-split img,.forge-video iframe,video{width:100%%;height:auto;border-radius:14px;aspect-ratio:16/10;object-fit:cover}.forge-video{position:relative;aspect-ratio:16/9}.forge-video iframe{position:absolute;inset:0;height:100%%}.forge-eyebrow{color:var(--a);font-weight:700;letter-spacing:.08em;text-transform:uppercase;font-size:13px}.forge-lede{font-size:19px;color:#3f3f3c}.forge-btn{display:inline-block;padding:14px 22px;border-radius:8px;font-weight:700;text-decoration:none;margin:6px 8px 6px 0}.forge-btn-primary{background:var(--p);color:#fff}.forge-btn-secondary{background:var(--a);color:#111}.forge-brand .forge-btn-primary{background:var(--a);color:#111}.forge-trust{list-style:none;padding:0;display:flex;flex-wrap:wrap;gap:8px 18px;font-size:14px}.forge-trust li:before{content:"✓ ";color:var(--p);font-weight:700}.forge-answer{font-size:20px;border-left:4px solid var(--p);padding-left:16px}.forge-facts{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px}.forge-facts div{background:#fff;border-radius:12px;padding:22px;box-shadow:0 1px 3px rgba(0,0,0,.08)}.forge-facts dt{font-size:34px;font-weight:800;color:var(--p)}.forge-brand .forge-facts div{background:rgba(255,255,255,.08)}.forge-brand .forge-facts dt{color:#fff}.forge-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:24px}.forge-card{background:#fff;border-radius:12px;padding:22px;box-shadow:0 1px 3px rgba(0,0,0,.08);margin:0}.forge-steps li{margin-bottom:14px}.forge-faq{border-bottom:1px solid #e3e1da;padding:10px 0}.forge-faq summary{cursor:pointer;list-style:none}.forge-faq summary h3{display:inline;font-size:18px}.forge-form{display:grid;gap:12px;max-width:560px}.forge-form label{display:grid;gap:4px;font-weight:600}.forge-form input,.forge-form textarea{padding:12px;border:1px solid #c3c0b7;border-radius:8px;font:inherit}.forge-consent{font-weight:400!important;font-size:13px;grid-template-columns:auto 1fr;align-items:start}.forge-form button{justify-self:start;border:0;cursor:pointer}.forge-table{width:100%%;border-collapse:collapse}.forge-table th,.forge-table td{padding:10px;border-bottom:1px solid #e3e1da;text-align:left}.forge-tablewrap{overflow-x:auto}.forge-links{columns:2}.forge-sticky{display:none}@media(max-width:767px){.forge-split{grid-template-columns:1fr}.forge-section{padding:44px 16px}.forge-sticky{display:flex;position:fixed;left:0;right:0;bottom:0;z-index:99;gap:8px;padding:10px 12px;background:#fff;box-shadow:0 -4px 16px rgba(0,0,0,.14)}.forge-sticky a{flex:1;text-align:center;padding:12px;border-radius:8px;font-weight:700;text-decoration:none}.forge-sticky-call{background:var(--a);color:#111}.forge-sticky-cta{background:var(--p);color:#fff}body{padding-bottom:70px}}'''

def preview_page(f, body, schema, seo):
    b = f.brand; p = f.cta.get('primary', {}); tl = tel(p['phone']) if p.get('phone') else None
    sticky = ('<div class="forge-sticky">' + (f'<a class="forge-sticky-call" href="{esc(tl)}">Call now</a>' if tl else '') + (f'<a class="forge-sticky-cta" href="{esc(p.get("url", "#contact"))}">{esc(p.get("label", "Get started"))}</a>' if p else '') + '</div>') if f.page.get('conversion', {}).get('sticky_mobile_bar', True) else ''
    css = PREVIEW_CSS % {'p': f.primary, 'a': f.accent, 't': f.tint, 'd': f.dark, 'font': b.get('font_body', 'system-ui, -apple-system, Segoe UI, Roboto, sans-serif'), 'hfont': b.get('font_heading', 'inherit')}
    return f'<!DOCTYPE html><html lang="{esc(f.page.get("language", "en-US")[:2])}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(seo["title"])}</title><meta name="description" content="{esc(seo["description"])}"><style>{css}</style><script type="application/ld+json">{json.dumps(schema, ensure_ascii=False)}</script></head><body><main>{body}</main>{sticky}</body></html>'

def compile_blueprint(bp, media=None, seed=None):
    if seed is not None: random.seed(seed)
    f = Forge(bp, media); content = f.elementor(); html_ = f.html(); schema = f.schema(); seo = f.seo()
    return {'template': f.template_file(content), 'elementor_data': content, 'page_settings': f.page_settings(), 'html': html_, 'preview': preview_page(f, html_, schema, seo), 'schema': schema, 'seo': seo, 'lint': f.lint(), 'page': bp['page'], 'blueprint': bp}

if __name__ == '__main__':
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    bp = json.load(open(sys.argv[1], encoding='utf-8')); out = sys.argv[2]; os.makedirs(out, exist_ok=True)
    media = json.load(open(sys.argv[sys.argv.index('--media') + 1], encoding='utf-8')) if '--media' in sys.argv else {}
    r = compile_blueprint(bp, media)
    bp['media_resolved'] = {k: {kk: vv for kk, vv in v.items() if kk in ('id', 'url', 'alt', 'kind', 'width', 'height', 'mime')} for k, v in (media or {}).items()}
    s = bp['page']['slug']
    json.dump(r['template'], open(os.path.join(out, f'{s}.elementor-template.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    json.dump({'slug': s, 'title': bp['page'].get('title'), 'post_title': bp['page']['h1'], 'status': 'draft', 'post_type': bp['page'].get('post_type', 'page'), 'template': r['page_settings']['template'], 'elementor_data': r['elementor_data'], 'page_settings': r['page_settings'], 'content_html': r['html'], 'seo': r['seo'], 'schema': r['schema'], 'blueprint': bp, 'summary': bp['page'].get('summary', ''), 'featured_media': (media.get(next((x['media'] for x in bp['sections'] if x['type'] == 'hero' and x.get('media')), '')) or {}).get('id', 0)}, open(os.path.join(out, f'{s}.bundle.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    open(os.path.join(out, f'{s}.content.html'), 'w', encoding='utf-8').write(r['html']); open(os.path.join(out, f'{s}.preview.html'), 'w', encoding='utf-8').write(r['preview'])
    json.dump(r['schema'], open(os.path.join(out, f'{s}.schema.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('wrote', out, '| sections', len(r['elementor_data']), '| lint:', ('\n  - ' + '\n  - '.join(r['lint'])) if r['lint'] else 'clean')
```
