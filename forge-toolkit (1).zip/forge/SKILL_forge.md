---
name: forge
description: FORGE builds and deploys WordPress pages from one blueprint - Elementor templates (importable JSON or written straight onto a page), headless Next.js front ends and semantic HTML - engineered for AI-search citation, classic SEO and conversion, with a media-library pipeline (upload, reuse, WebP, alt text, video) and a built-in WordPress connector (REST plus the FORGE bridge plugin). Use for any request to create, generate, template, redesign, migrate or deploy WordPress, Elementor or headless pages, landing, service, location or practice pages, or to push content, images or video onto a WordPress site. Never uses Ahrefs.
---

# FORGE

FORGE takes a page brief and returns a deployed WordPress page. One JSON **blueprint** compiles into an Elementor template, the `_elementor_data` written straight onto a page, a semantic HTML fallback, a standalone preview, a JSON-LD entity graph and a headless Next.js front end — every target built to be cited by AI search, ranked by classic search and converted by humans. The toolkit (compiler, WordPress connector, bridge plugin, headless generator) travels inside this skill and its two companion skills, `forge-compiler` and `forge-bridge`; materialize it once per session (Phase 0) and drive it from the shell. Nothing is hand-written into `_elementor_data`, nothing is guessed about the site, nothing goes live without the user saying so.

Voice: direct, decisive, no filler. Flag every judgment call in one line. Report results as lists of links.

## Articles (non-negotiable)

1. **No Ahrefs. Ever.** FORGE never calls any `mcp__Ahrefs__*` tool, for any reason, even when asked to "just check" something — say so once and use the live site, its sitemap and WebFetch/WebSearch instead.
2. **Drafts by default.** Every import lands as `draft`. Publish only when the user says "publish" in this conversation (then `--status publish`).
3. **Every internal link is live or it is gone.** `links-check` (sitemap membership or HEAD < 400) must exit 0 before deploy. Never invent a URL.
4. **Nothing placeholder ships.** Lint lines starting `BLOCK:` (unresolved media, `[[verify`, lorem ipsum, TODO) stop deployment. Facts carry a `source`; numbers the user did not supply are researched with WebSearch/WebFetch and cited, or left out.
5. **Elementor data goes through the bridge or Elementor's own importer** — never through hand-edited post meta, theme files or `functions.php`.
6. **Credentials live in environment variables only.** Application Password auth; never written into files, blueprints, logs, memory or the reply. Never echo `WP_APP_PASS`.
7. **One working directory, few prompts.** Everything lives in `forge/` under the working directory; chain shell steps into one command where sensible so the user is not flooded with permission prompts.
8. **Verify before you report.** Compiled preview → lint → links-check → (after publish) live `verify`. Report what was checked, never what was intended.
9. **Ask once, then run.** User present: one AskUserQuestion (max 4 questions) at the brief stage. Unattended: pick the sensible default, state it at the top of the reply, keep going.

## Quick start (all commands run from `forge/`)

```
# 0  materialize the toolkit into forge/ (Phase 0), then: cd forge
# 1  export WP_URL=https://www.site.com WP_USER=name WP_APP_PASS='xxxx xxxx xxxx xxxx xxxx xxxx'; python3 forge_wp.py status
# 2  write <slug>.blueprint.json (Phase 3 schema; start from sample_blueprint.json); local media into assets/
# 3  python3 forge_wp.py media-resolve <slug>.blueprint.json <slug>.media.json --reuse
# 4  python3 forge_compile.py <slug>.blueprint.json out --media <slug>.media.json      # lint: no BLOCK lines
# 5  python3 forge_wp.py links-check <slug>.blueprint.json                              # exit 0 or fix the links
# 6  python3 forge_wp.py import out/<slug>.bundle.json --media <slug>.media.json       # draft; returns link + Elementor edit link
# 7  report: links, media IDs, accepted warnings, judgment calls, next actions
```

Files: `forge_compile.py` (blueprint → template / bundle / HTML / preview / schema + lint) · `forge_wp.py` (connector CLI: status, media-find, media-upload, media-resolve, import, template, settings, verify, sitemap, links-check, indexnow, bridge-zip) · `forge-bridge.php` (WordPress plugin: `forge/v1` REST namespace, JSON-LD in `wp_head`, Yoast/RankMath/SEOPress fields, llms.txt, IndexNow, lead endpoint, headless revalidation, CORS, nav) · `forge_headless.py` (Next.js 15 App Router generator) · `sample_blueprint.json` (reference blueprint: a law-firm location page).

## Phase 0 — Materialize the toolkit (once per session)

1. If `forge/forge_compile.py` exists, skip to Phase 1.
2. `mkdir -p forge forge/assets`. Load the two companion skills with the Skill tool — `forge-compiler` (carries `forge_compile.py`) and `forge-bridge` (carries `forge-bridge.php` and `forge_headless.py`) — then write every file from their appendices and from Appendix A below (`forge_wp.py`, `sample_blueprint.json`) to `forge/<name>` **verbatim** with the Write tool: one call per file, no edits, no "improvements", no reformatting. The companion skills are source containers only; never follow them on their own.
3. Dependencies: `python3 -c "import requests, PIL" 2>/dev/null || pip install requests pillow --break-system-packages`. Node ≥ 20 only for the headless route; `php -l forge/forge-bridge.php` is optional.
4. Smoke test: `cd forge && python3 forge_compile.py sample_blueprint.json out_smoke` → expect `sections 13` and exactly four `BLOCK: media slot … unresolved` lines (no media map yet). Anything else means a file was mis-written: rewrite it from its appendix. Then `rm -rf out_smoke`.

## Phase 1 — Brief

Read the live site before asking anything: `python3 forge_wp.py sitemap --base https://www.site.com`, then WebFetch the home page and one sibling page for brand tokens (`:root` variables, Elementor global colours/fonts in the page CSS), the phone number, the nav CTA wording and the writing voice. Establish:

- **Target**: site URL; route = Elementor page (default when Elementor is installed) | Elementor saved template (user places it) | headless Next.js | HTML-only (no Elementor); post type; parent page.
- **Page**: archetype, slug, working title, the one question the page must answer, primary conversion (call / form / booking), phone, form provider, author or reviewer with credentials and profile URL.
- **Brand**: primary / accent / dark hex, heading and body fonts, logo URL. Confirm only if the site is inconsistent.
- **Entities and facts**: organisation name, address, phone, areaServed, sameAs; the 3–6 hard facts with sources that make the page citable.
- **Media**: what the library already has (`media-find`), what the user will supply, what must be sourced. Never hotlink third-party images; never use stock that misrepresents the business.
- **Internal links**: 2–6 live sibling/parent URLs taken from the sitemap.

If the user is present, one AskUserQuestion covering only what the site could not answer (typically route, form provider, media sources, draft vs publish). Unattended: Elementor page, draft, HTML lead form, sticky bar on — and say so.

### Archetypes (section order)

- **service / practice**: hero (split) → answer → key_facts → rich_text (who qualifies, process, cost) → features (why us) → steps → testimonials → faq → authors → cta_band → form → links
- **location** (city + service): hero → answer (city-specific) → key_facts (local deadlines, courts, numbers with sources) → rich_text → steps → video → testimonials (local) → faq (city-phrased) → authors → map → cta_band → form → links; `page.service.areaServed` = the city
- **article / guide**: hero (center, no media or one) → answer → key_facts → rich_text × N (one H2 per question people ask) → table → faq → authors → cta_band → links; `archetype: article` adds Article schema
- **landing / campaign** (paid traffic): hero (cover or split, one CTA) → key_facts or stats → features → testimonials → faq (objections) → form → cta_band; `sticky_mobile_bar: true`, no `links`, `noindex: true` when it duplicates an organic page
- **home**: hero → stats → features (services, each linking) → answer (who we are) → testimonials → steps → faq → cta_band → links
- **about / person**: hero (split, headshot) → rich_text (bio) → key_facts (credentials, years, bar numbers) → gallery → testimonials → faq → cta_band; the Person goes in `page.entity` or `schema_extra`
- **comparison / alternatives**: hero → answer → table → rich_text per option → faq → cta_band → links

### The standard every page meets (the lint enforces the first line; you enforce the rest)

- Title ≤ 60 chars, primary term first · meta description 120–158 · exactly one hero, H1 ≤ 70 · an `answer` capsule directly after the hero (2–4 sentences that answer the query outright, quotable, no marketing) · a `faq` with 4–8 real questions · a primary CTA with a phone · alt text on every media slot · internal links declared and live · no placeholder text.
- H2s phrased as the questions people ask · every `key_facts` item carries a `source` · `page.dates` set and updated on edits · `author` with credentials and profile URL (becomes `reviewedBy`) · `summary` in one sentence (feeds llms.txt).
- Entity graph, automatic: Organization (or the `@type` in `page.entity`, e.g. LegalService, MedicalBusiness, LocalBusiness) + WebSite + WebPage (with `speakable` on the answer) + BreadcrumbList + FAQPage + Service (service/location/practice) + Article (article) + VideoObject (video) + HowTo (steps with `howto: true`) + Person (author). Anything else goes in `page.schema_extra`.
- Conversion: CTA above the fold · trust strip of three short proofs · sticky mobile bar (call + CTA) · a `cta_band` before the form · form of ≤ 4 fields plus consent, honest consent language · `#contact` anchor · confirmation message · `forge_lead` dataLayer event on success.
- Performance: hero image `priority: true` (≤ 1920 px WebP), everything else ≤ 1600 px and lazy · video through the YouTube-nocookie facade or self-hosted MP4 with a poster · no third-party embeds above the fold · no autoplay with sound.
- Writing: specific beats generic, second person, no adjective walls, no claims the business cannot back, plain-language accuracy on legal/medical/financial facts, the site's spelling convention.

## Phase 2 — Connect to WordPress

1. **Application Password** (the only auth FORGE uses): WP Admin → Users → Profile → *Application Passwords* → name `FORGE` → *Add New* → copy the 24-character password (shown once). Needs HTTPS (or `WP_ENVIRONMENT_TYPE=local`) and a REST API not blocked by a security plugin. Elementor imports need an Administrator (the `unfiltered_html` capability).
2. `export WP_URL=https://www.site.com WP_USER=name WP_APP_PASS='xxxx xxxx …'` (spaces are fine; `WP_INSECURE=1` only for self-signed dev hosts). If the user must hand the password over in chat, use it in the shell and nowhere else.
3. `python3 forge_wp.py status` → confirms auth; with the bridge it reports Elementor and Pro versions, `containers`, theme, permalinks, SEO plugin, form plugins, WPGraphQL, `upload_max`, `unfiltered_html`.
4. **Install the bridge** (required for Elementor imports, JSON-LD, SEO-plugin fields, llms.txt, leads, headless nav and revalidation). One of: (a) `python3 forge_wp.py bridge-zip` → send `forge-bridge.zip` with SendUserFile → user: Plugins → Add New → Upload Plugin → Activate; (b) copy `forge-bridge.php` into `wp-content/mu-plugins/` over SFTP or the host's file manager (self-activating); (c) when the session is linked to the user's computer and the site runs locally (Local, DDEV, wp-env), copy it with the device shell. It cannot be installed over REST. Re-run `status` until `bridge: true`.
5. Without the bridge FORGE still searches and uploads media, imports the **HTML fallback** as page content over core REST, and produces `.elementor-template.json` for manual import (Templates → Saved Templates → Import Templates). It cannot write Elementor data, JSON-LD or SEO-plugin fields — say so in the report.
6. Egress: if the cloud shell cannot reach the site (private network, IP allowlist), run the same commands through the linked computer's shell; with no link, hand over the files with SendUserFile plus the exact commands.

## Phase 3 — Write the blueprint

`forge/<slug>.blueprint.json`:

```
forge: "1"
site: { url, name, cms (WordPress URL when it differs from the public site), footer_line,
        brand: { name, primary, accent, dark, font_heading, font_body, logo_url,
                 globals: true (use Elementor Site Settings colours/typography) | false (write literal brand hex) } }
page: { archetype: service|practice|location|article|landing|home|about|comparison, post_type: page|post,
        slug, title, h1, meta_description, language, template: default|elementor_header_footer|elementor_canvas,
        parent, canonical, noindex, breadcrumbs: [{name,url}], summary,
        entity: {@type, name, telephone, address{…}, areaServed[], sameAs[], priceRange},
        service: {@type: Service, serviceType, areaServed}, author: {name, credentials, url, bio, media},
        dates: {published, modified}, cta: { primary: {label,url,phone,phone_label}, secondary: {label,url} },
        conversion: { sticky_mobile_bar, trust: [three strings],
                      form: { provider: html|elementor_pro|wpforms|gravity|cf7|fluent|shortcode, shortcode,
                              fields: [{id,label,type,required}], consent, button, email_to, action } },
        internal_links: [{anchor,url}], schema_extra: [], custom_css }
media: { <slot>: { source: "assets/x.jpg" | "https://…" | "library:<search words>" | "library:<id>",
                   alt, kind: image|video, priority, title, caption, rename } }
sections: [ … ]   # each: type, optional id, style: light|tint|dark|brand, width: boxed|narrow
```

Section types: `hero` (eyebrow, h1, lede, media, poster, layout split|cover|center, cta [keys], trust) · `answer` (heading, body) · `key_facts` (heading, items[{value,label,source}]) · `rich_text` (heading, tag, html) · `steps` (heading, steps[{title,text}], howto) · `features` (heading, text, items[{title,text,icon}]) · `media` (media, heading, caption) · `video` (media, poster, heading, transcript, description) · `gallery` (media[], columns) · `testimonials` (heading, items[{quote,name,role,rating,media}]) · `stats` (heading, items[{value,label}]) · `faq` (heading, items[{q,a}]) · `cta_band` (heading, text, cta) · `form` (heading, text — fields from page.conversion.form) · `map` (heading, address, text) · `table` (heading, columns, rows) · `authors` (heading — from page.author) · `links` (heading, items or page.internal_links) · `html` (html — escape hatch, sparingly).

`rich_text.html` is clean HTML (p, ul, ol, strong, a) used as-is in every target; everything else is plain text and escaped by the compiler. Start from `sample_blueprint.json`, replace every value, keep the section discipline of the archetype. Testimonials are real quotes the user supplied or that exist on the site — never invented.

**Site Forge packs.** When the user hands over a pack built by the Termination Exposure Atlas's module eight (a zip with `plan.json`, `ledger.csv`, `blueprints/`, `bundles/`, `elementor/`, `html/`, `preview/`, `schema/`, `assets/`, `media/` and `forge-bridge.php`), the blueprints are already written, linted and cross-linked: skip Phase 3. Read `plan.json` and `ledger.csv` for the page set, unzip the pack beside the toolkit, resolve media with `--assets pack` (sources are `assets/<file>`, already WebP), then run Phases 5–7 per page (`pack/README.md` carries the exact commands). Links between pack pages go live only when the whole set is published, so deploy the set together and run `links-check` after publishing; before that, a links-check failure that names only pack pages is expected and is not a reason to remove the links. The pack's `forge-bridge.php` is bridge 1.1 (browser-side CORS, `forge/v1/urls`); install it if the site runs an older bridge.

## Phase 4 — Media

1. Search before uploading: `python3 forge_wp.py media-find "jane doe headshot"`; reuse with `library:<words>` or `library:<id>` as the slot source.
2. Local files go in `forge/assets/` and are referenced as `assets/<file>`; `https://` images are downloaded then uploaded (only from sources the user owns or licensed — note it in the report); YouTube/Vimeo URLs are embedded, not uploaded.
3. `python3 forge_wp.py media-resolve <slug>.blueprint.json <slug>.media.json --reuse` → optimises (EXIF-rotated WebP, ≤ 1600 px, hero ≤ 1920 px), renames `<slug>-<slot>`, sets alt/title/caption, reuses a matching library file, skips slots already resolved, prints `✓`/`!` per slot. Fix every `!` before compiling. `--dry` previews without uploading.
4. Video: self-hosted MP4/WebM must be under `upload_max` from `status` (otherwise YouTube unlisted or a CDN URL); always supply a `poster`; add a `transcript` (feeds VideoObject and accessibility).
5. Alt text describes the image and names the entity or place when true ("Attorney Jane Doe at the firm's Houston office") — never keyword-stuffed, never empty.

## Phase 5 — Compile, preview, gate

`python3 forge_compile.py <slug>.blueprint.json out --media <slug>.media.json` writes `out/<slug>.elementor-template.json` (Elementor import file), `.bundle.json` (what the bridge consumes), `.content.html` (fallback content), `.preview.html` (open or screenshot it), `.schema.json`, and prints the lint.

Gates, in order: (1) lint has no `BLOCK:` line and every other warning is fixed or explicitly accepted in the report; (2) `python3 forge_wp.py links-check <slug>.blueprint.json` exits 0; (3) preview reviewed — with Playwright/Chromium available, screenshot `out/<slug>.preview.html` at 1365 px and 390 px and look for broken layout, empty sections, placeholder images. Send the preview to the user (SendUserFile) when they asked to see it first or when a layout/copy judgment needs their eye. Only then deploy.

## Phase 6 — Deploy (the route chosen in Phase 1)

- **Elementor page (default)**: `python3 forge_wp.py import out/<slug>.bundle.json --media <slug>.media.json` → draft page carrying `_elementor_data` (flex containers), page settings, HTML fallback content, featured image, SEO fields (Yoast / RankMath / SEOPress), JSON-LD and the blueprint. Returns `id`, `link`, `edit` (Elementor editor). Re-running updates the same slug in place. `--status publish` only on explicit instruction.
- **Elementor saved template**: `python3 forge_wp.py template out/<slug>.elementor-template.json` → Templates → Saved Templates. Without the bridge, send the JSON file; the user imports it (Templates → Saved Templates → Import Templates). Header/footer stay the site's theme or Pro templates: `page.template: elementor_header_footer` keeps them, `elementor_canvas` drops them (landing pages).
- **Headless (Next.js 15, App Router, TypeScript)**: `python3 forge_headless.py <slug>.blueprint.json headless --wp https://cms.site.com --site https://www.site.com` → project with ISR (10 min), on-demand revalidation, `generateMetadata`, JSON-LD, `next/image` for library images, sitemap / robots / llms.txt, lead proxy, YouTube facade, nav from the bridge. `cd headless && npm install && npm run build` must pass. Deploy (Vercel, Netlify, Node) with `WP_URL`, `NEXT_PUBLIC_SITE_URL`, `REVALIDATE_SECRET`, `WP_HOME_SLUG`; then register it: `python3 forge_wp.py settings --revalidate-url https://www.site.com/api/revalidate --secret <REVALIDATE_SECRET> --cors https://www.site.com`. Pages are still imported with `import` (the front end reads `forge.blueprint` over REST); WordPress stays on `cms.` and canonicals point at the front end. Hand the project over as a zip (`zip -r headless.zip headless -x "headless/node_modules/*" "headless/.next/*"`) when the user deploys it.
- **HTML-only** (no Elementor; Gutenberg or classic themes): `import` writes `.content.html` as post content; with the bridge it also writes JSON-LD and SEO fields. Styling comes from `PREVIEW_CSS` — add it once under Appearance → Customize → Additional CSS, or per page via `page.custom_css`.

After a publish: `python3 forge_wp.py indexnow <url>` (requires `settings --indexnow-key <32 hex>`; the bridge serves the key file) and point the user at Search Console URL inspection.

## Phase 7 — Verify and report

- Drafts are not publicly fetchable: verify the compiled preview and the import response now; the moment the page is published run `python3 forge_wp.py verify <url>` (status, title, meta, canonical, robots, H1s, H2 count, JSON-LD types, images without alt, lazy count, form present, Elementor markers). Include Rich Results Test and PageSpeed Insights links with the URL pre-filled.
- Report, links first, no pipeline recap: page link and Elementor edit link · route and status (draft/publish) · media created or reused with IDs · lint warnings accepted and why · internal links verified (count) · judgment calls (one line each) · next actions for the user (publish, set Global Colours, install bridge, add to the menu, connect the form's email).

## Judgment calls to flag (one line each, every time)

Brand tokens read off the site vs. supplied · `globals: true` (needs Site Settings colours set) vs. literal hex · flex containers required (`containers` from status; older section-based sites enable Flexbox Container under Elementor → Settings → Features) · form provider chosen · `noindex` on landing pages · trimmed titles or meta · any fact researched rather than supplied, with its source · media reused from the library vs. uploaded · everything left as draft awaiting the user.

## Troubleshooting

`401 rest_not_logged_in` / `incorrect_password` → wrong application password, no HTTPS, or a security plugin disables application passwords · `403 forge_caps` → the account lacks `unfiltered_html` (not an Administrator): Elementor data cannot be imported — HTML-only route or an admin account · `404 rest_no_route` on `forge/v1` → bridge inactive, or permalinks set to Plain (choose Post name) · `413`/`500` on upload → over `upload_max`; resize or raise the PHP limit · page blank in the Elementor editor → Elementor → Tools → Regenerate CSS & Data · widgets show Elementor's default blue → Global Colours not set: set them or recompile with `brand.globals: false` · headless build fails on `remotePatterns` → `WP_URL` host mismatch · lead emails missing → `lead_email` in settings and the host's mail; leads are also stored under *FORGE leads* in wp-admin · CORS errors from the headless form → `settings --cors https://front-end` · `pip` missing `PIL` → `pip install pillow --break-system-packages`.

## Appendix A — Sources carried by this skill (write each verbatim to `forge/`)

### forge/forge_wp.py

```python
#!/usr/bin/env python3
"""FORGE WordPress connector — REST client over Application Passwords, plus the media pipeline.
Env: WP_URL (https://site.com), WP_USER, WP_APP_PASS (Application Password, spaces allowed). Optional: WP_INSECURE=1 for self-signed dev hosts.
Commands:
  status                                  bridge + site capabilities (falls back to core REST if the bridge is absent)
  media-find "query"                      search the media library (bridge, or core /wp/v2/media?search=)
  media-upload path --alt "…" [--title "…"] [--caption "…"] [--reuse] [--max 1600] [--webp]   optimise + upload, print JSON
  media-resolve blueprint.json media_map.json [--assets DIR] [--reuse] [--dry]   resolve every media slot (path / URL / library:query / library:ID) → media_map.json
  import bundle.json [--status draft|publish] [--media media_map.json]           create/update the page through the bridge (or core REST without Elementor data)
  template template.json                                                          add an Elementor saved template through the bridge
  settings [--revalidate-url U] [--secret S] [--cors https://a.com,https://b.com] [--lead-email E] [--indexnow-key K]
  verify URL                              fetch a live page: title, meta, canonical, H1s, JSON-LD types, image alts, form present
  indexnow URL [URL…]                     ping IndexNow through the bridge
  sitemap [--base https://site]           list every URL in the live XML sitemap(s)
  links-check blueprint.json [--base U]   every internal link must be in the live sitemap (or answer HEAD < 400); exits 2 otherwise
  bridge-zip [forge-bridge.php]           zip the bridge as an installable plugin (Plugins → Add New → Upload)
"""
import os, sys, json, re, io, base64, mimetypes, hashlib, time
import requests

WP = os.environ.get('WP_URL', '').rstrip('/'); USER = os.environ.get('WP_USER', ''); PASS = os.environ.get('WP_APP_PASS', '')
VERIFY = not os.environ.get('WP_INSECURE')
S = requests.Session(); S.headers['User-Agent'] = 'FORGE/1.0 (+WordPress connector)'
if USER and PASS: S.auth = (USER, PASS)

def die(m, code=1): print('ERROR:', m, file=sys.stderr); sys.exit(code)
def api(path): return f"{WP}/wp-json/{path.lstrip('/')}"
def req(method, path, **kw):
    kw.setdefault('timeout', 60); kw.setdefault('verify', VERIFY)
    r = S.request(method, api(path), **kw)
    if r.status_code >= 400:
        try: j = r.json(); msg = j.get('message') or j
        except Exception: msg = r.text[:300]
        raise RuntimeError(f'{method} {path} → {r.status_code}: {msg}')
    return r.json() if r.content else {}
def has_bridge():
    try: req('GET', 'forge/v1/status'); return True
    except RuntimeError as e:
        if '404' in str(e) or 'rest_no_route' in str(e): return False
        raise

# ---------- status ----------
def status():
    if not WP: die('WP_URL not set')
    core = req('GET', '')
    out = {'site': core.get('name'), 'url': core.get('url') or core.get('home'), 'namespaces': core.get('namespaces', [])[:12], 'bridge': False}
    if 'forge/v1' in core.get('namespaces', []):
        out['bridge'] = True; out.update(req('GET', 'forge/v1/status'))
    else:
        me = req('GET', 'wp/v2/users/me?context=edit'); out['user'] = me.get('slug'); out['caps'] = [k for k, v in (me.get('capabilities') or {}).items() if v and k in ('edit_pages', 'unfiltered_html', 'upload_files', 'manage_options')]
        out['elementor'] = 'elementor/v1' in core.get('namespaces', []) or None
    return out

# ---------- media ----------
def optimise(path, max_px=1600, webp=True, quality=82):
    """Resize to max_px on the long edge and re-encode as WebP (or keep type). Returns (bytes, filename, mime, w, h)."""
    from PIL import Image, ImageOps
    im = Image.open(path); im = ImageOps.exif_transpose(im); w, h = im.size
    if max(w, h) > max_px:
        r = max_px / max(w, h); im = im.resize((round(w * r), round(h * r)), Image.LANCZOS); w, h = im.size
    base = re.sub(r'[^a-z0-9]+', '-', os.path.splitext(os.path.basename(path))[0].lower()).strip('-')
    buf = io.BytesIO()
    if webp and im.mode in ('RGB', 'RGBA', 'P', 'L'):
        (im.convert('RGBA') if im.mode in ('P', 'RGBA') else im.convert('RGB')).save(buf, 'WEBP', quality=quality, method=6); return buf.getvalue(), base + '.webp', 'image/webp', w, h
    fmt = (im.format or 'JPEG'); im.save(buf, fmt, quality=quality); return buf.getvalue(), base + '.' + fmt.lower().replace('jpeg', 'jpg'), Image.MIME.get(fmt, 'image/jpeg'), w, h

def media_find(q, n=10):
    if has_bridge(): return req('GET', f'forge/v1/media/find?q={requests.utils.quote(q)}&per_page={n}')
    rows = req('GET', f'wp/v2/media?search={requests.utils.quote(q)}&per_page={n}&_fields=id,title,source_url,mime_type,alt_text,media_details')
    return [{'id': r['id'], 'title': r['title']['rendered'], 'url': r['source_url'], 'mime': r['mime_type'], 'alt': r.get('alt_text', ''), 'width': (r.get('media_details') or {}).get('width'), 'height': (r.get('media_details') or {}).get('height')} for r in rows]

def media_get(mid):
    r = req('GET', f'wp/v2/media/{mid}?_fields=id,title,source_url,mime_type,alt_text,media_details')
    return {'id': r['id'], 'title': r['title']['rendered'], 'url': r['source_url'], 'mime': r['mime_type'], 'alt': r.get('alt_text', ''), 'width': (r.get('media_details') or {}).get('width'), 'height': (r.get('media_details') or {}).get('height')}

def media_upload(path, alt='', title='', caption='', reuse=True, max_px=1600, webp=True, rename=None):
    mime, _ = mimetypes.guess_type(path); mime = mime or 'application/octet-stream'; data = None; fname = os.path.basename(path); w = h = None
    if mime.startswith('image/') and mime not in ('image/svg+xml', 'image/gif'):
        data, fname, mime, w, h = optimise(path, max_px, webp)
    else:
        data = open(path, 'rb').read()
    if rename: fname = rename + os.path.splitext(fname)[1]
    if reuse:
        stem = os.path.splitext(fname)[0]
        for m in media_find(stem, 5):
            if m['url'] and os.path.splitext(os.path.basename(m['url']))[0].startswith(stem) and m['mime'] == mime:
                if alt and m.get('alt') != alt: req('POST', f'wp/v2/media/{m["id"]}', json={'alt_text': alt})
                m['reused'] = True; return m
    r = S.post(api('wp/v2/media'), data=data, headers={'Content-Type': mime, 'Content-Disposition': f'attachment; filename="{fname}"'}, timeout=300, verify=VERIFY)
    if r.status_code >= 400: raise RuntimeError(f'upload {fname} → {r.status_code}: {r.text[:300]}')
    j = r.json(); mid = j['id']
    patch = {k: v for k, v in {'alt_text': alt, 'title': title or os.path.splitext(fname)[0].replace('-', ' '), 'caption': caption, 'description': alt}.items() if v}
    if patch: req('POST', f'wp/v2/media/{mid}', json=patch)
    det = j.get('media_details') or {}
    return {'id': mid, 'url': j['source_url'], 'mime': j['mime_type'], 'alt': alt, 'width': det.get('width') or w, 'height': det.get('height') or h, 'title': patch.get('title', '')}

def media_resolve(bp, assets_dir='.', reuse=True, dry=False, existing=None):
    """Resolve every media slot in the blueprint. source: local path | http(s) URL | library:<query> | library:<id>."""
    out = dict(existing or {}); slug = bp['page']['slug']
    for key, spec in (bp.get('media') or {}).items():
        if key in out and out[key].get('url'): continue
        src = spec.get('source', ''); kind = spec.get('kind', 'image'); alt = spec.get('alt', '')
        if src.startswith('library:'):
            q = src[8:].strip()
            if q.isdigit(): m = media_get(int(q))
            else:
                hits = media_find(q, 5) or media_find(re.sub(r'\s+', '-', q), 5); m = hits[0] if hits else None
            if not m: print(f'  ! {key}: nothing in the library for "{q}"'); continue
            if alt and m.get('alt') != alt and not dry: req('POST', f'wp/v2/media/{m["id"]}', json={'alt_text': alt}); m['alt'] = alt
            out[key] = dict(m, kind=kind); print(f'  ✓ {key}: library #{m["id"]} {m["url"]}'); continue
        if re.match(r'^https?://', src):
            if kind == 'video' or re.search(r'(youtube\.com|youtu\.be|vimeo\.com)', src): out[key] = {'id': 0, 'url': src, 'alt': alt, 'kind': kind}; print(f'  ✓ {key}: external {src}'); continue
            r = requests.get(src, timeout=120); r.raise_for_status(); tmp = os.path.join(assets_dir, f'.forge-{key}{os.path.splitext(src.split("?")[0])[1] or ".jpg"}'); open(tmp, 'wb').write(r.content); src = tmp
        p = src if os.path.isabs(src) else os.path.join(assets_dir, src)
        if not os.path.exists(p): print(f'  ! {key}: file not found {p}'); continue
        if dry: out[key] = {'id': 0, 'url': 'file://' + p, 'alt': alt, 'kind': kind}; continue
        m = media_upload(p, alt=alt, title=spec.get('title', ''), caption=spec.get('caption', ''), reuse=reuse, max_px=1920 if spec.get('priority') else 1600, webp=kind == 'image', rename=f"{slug}-{key}" if spec.get('rename', True) else None)
        m['kind'] = kind; out[key] = m; print(f'  ✓ {key}: {"reused" if m.get("reused") else "uploaded"} #{m["id"]} {m["url"]}')
    return out

# ---------- pages ----------
def import_bundle(bundle, status=None, media=None):
    if status: bundle['status'] = status
    if media and not bundle.get('featured_media'):
        hero = next((s.get('media') for s in bundle['blueprint']['sections'] if s['type'] == 'hero' and s.get('media')), None)
        if hero and media.get(hero, {}).get('id'): bundle['featured_media'] = media[hero]['id']
    if has_bridge(): return req('POST', 'forge/v1/import', json=bundle)
    # no bridge: core REST only — HTML fallback content, no Elementor data, SEO via registered meta if the SEO plugin exposes it
    print('  ! bridge not installed: importing HTML content only (no Elementor data, no JSON-LD). Install forge-bridge.php for the full deploy.', file=sys.stderr)
    pt = 'posts' if bundle.get('post_type') == 'post' else 'pages'
    ex = req('GET', f'wp/v2/{pt}?slug={bundle["slug"]}&status=any&_fields=id')
    body = {'slug': bundle['slug'], 'title': bundle['post_title'], 'status': bundle.get('status', 'draft'), 'content': bundle.get('content_html', ''), 'excerpt': bundle.get('summary', '')}
    if bundle.get('featured_media'): body['featured_media'] = bundle['featured_media']
    r = req('POST', f'wp/v2/{pt}/{ex[0]["id"]}' if ex else f'wp/v2/{pt}', json=body)
    return {'id': r['id'], 'link': r.get('link'), 'updated': bool(ex), 'bridge': False}

def import_template(tpl):
    if not has_bridge(): die('the bridge is required for saved-template import; alternatively import the JSON file via Elementor → Templates → Import Templates')
    return req('POST', 'forge/v1/template', json={'title': tpl['title'], 'content': tpl['content'], 'page_settings': tpl.get('page_settings', {}), 'type': tpl.get('type', 'page')})

def settings(**kw):
    body = {k: v for k, v in kw.items() if v is not None}
    return req('POST', 'forge/v1/settings', json=body) if body else req('GET', 'forge/v1/settings')

# ---------- verification ----------
def verify(url):
    r = requests.get(url, timeout=60, headers={'User-Agent': S.headers['User-Agent']}, verify=VERIFY); h = r.text
    g = lambda pat: [re.sub(r'\s+', ' ', x).strip() for x in re.findall(pat, h, re.I | re.S)]
    ld = [];
    for blk in re.findall(r'<script[^>]*application/ld\+json[^>]*>(.*?)</script>', h, re.I | re.S):
        try: j = json.loads(blk); ld.extend([x.get('@type') for x in (j.get('@graph') if isinstance(j, dict) and '@graph' in j else [j])])
        except Exception as e: ld.append('INVALID JSON-LD: ' + str(e)[:60])
    imgs = re.findall(r'<img\b[^>]*>', h, re.I); noalt = [i for i in imgs if not re.search(r'\balt="[^"]+"', i)]
    return {'status': r.status_code, 'bytes': len(h), 'title': (g(r'<title[^>]*>(.*?)</title>') or [''])[0], 'meta_description': (g(r'<meta\s+name="description"\s+content="([^"]*)"') or [''])[0], 'canonical': (g(r'<link\s+rel="canonical"\s+href="([^"]*)"') or [''])[0], 'robots': g(r'<meta\s+name="robots"\s+content="([^"]*)"'), 'h1': g(r'<h1[^>]*>(.*?)</h1>'), 'h2_count': len(g(r'<h2[^>]*>')), 'jsonld_types': ld, 'images': len(imgs), 'images_without_alt': len(noalt), 'has_form': bool(re.search(r'<form\b', h, re.I)), 'elementor': 'elementor' in h, 'lazy_images': len(re.findall(r'loading="lazy"', h))}

# ---------- sitemap + internal-link check (never link to a URL that is not live) ----------
def sitemap_urls(base=None, limit=5000):
    base = (base or WP).rstrip('/'); seen = set(); out = []
    def grab(u, depth=0):
        if depth > 2 or len(out) >= limit: return
        try: t = requests.get(u, timeout=30, headers={'User-Agent': S.headers['User-Agent']}, verify=VERIFY).text
        except Exception: return
        subs = re.findall(r'<sitemap>\s*<loc>(.*?)</loc>', t, re.S)
        for s_ in subs: grab(s_.strip(), depth + 1)
        for loc in re.findall(r'<url>\s*<loc>(.*?)</loc>', t, re.S):
            l = loc.strip()
            if l not in seen: seen.add(l); out.append(l)
    for cand in ('/sitemap_index.xml', '/sitemap.xml', '/wp-sitemap.xml'):
        grab(base + cand)
        if out: break
    return out
def links_check(bp, base=None):
    base = (base or WP or bp.get('site', {}).get('url', '')).rstrip('/'); urls = set(u.rstrip('/') for u in sitemap_urls(base)); res = []; seen = set()
    for l in bp['page'].get('internal_links', []) + [x for s in bp['sections'] if s['type'] == 'links' for x in s.get('items', [])]:
        u = l['url'] if re.match(r'^https?://', l['url']) else base + l['url']
        if u in seen: continue
        seen.add(u); ok = u.rstrip('/') in urls; how = 'sitemap'
        if not ok:
            try: ok = requests.head(u, timeout=20, allow_redirects=True, headers={'User-Agent': S.headers['User-Agent']}, verify=VERIFY).status_code < 400; how = 'HEAD'
            except Exception: ok = False
        res.append({'anchor': l['anchor'], 'url': u, 'live': ok, 'via': how if ok else 'missing'})
    return res
def bridge_zip(src, out='forge-bridge.zip'):
    import zipfile
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z: z.write(src, 'forge-bridge/forge-bridge.php')
    return out

# ---------- CLI ----------
def main(a):
    if not a: print(__doc__); return
    cmd = a[0]; opt = lambda k, d=None: (a[a.index(k) + 1] if k in a else d); flag = lambda k: k in a
    if cmd == 'status': print(json.dumps(status(), indent=1))
    elif cmd == 'media-find': print(json.dumps(media_find(a[1]), indent=1))
    elif cmd == 'media-upload': print(json.dumps(media_upload(a[1], alt=opt('--alt', ''), title=opt('--title', ''), caption=opt('--caption', ''), reuse=flag('--reuse'), max_px=int(opt('--max', 1600)), webp=flag('--webp') or True), indent=1))
    elif cmd == 'media-resolve':
        bp = json.load(open(a[1], encoding='utf-8')); out_path = a[2]; existing = json.load(open(out_path, encoding='utf-8')) if os.path.exists(out_path) else {}
        m = media_resolve(bp, opt('--assets', '.'), reuse=flag('--reuse'), dry=flag('--dry'), existing=existing); json.dump(m, open(out_path, 'w', encoding='utf-8'), indent=1); print('wrote', out_path, len(m), 'slots')
    elif cmd == 'import':
        b = json.load(open(a[1], encoding='utf-8')); media = json.load(open(opt('--media'), encoding='utf-8')) if opt('--media') else None
        print(json.dumps(import_bundle(b, opt('--status'), media), indent=1))
    elif cmd == 'template': print(json.dumps(import_template(json.load(open(a[1], encoding='utf-8'))), indent=1))
    elif cmd == 'settings': print(json.dumps(settings(revalidate_url=opt('--revalidate-url'), revalidate_secret=opt('--secret'), cors_origins=(opt('--cors').split(',') if opt('--cors') else None), lead_email=opt('--lead-email'), indexnow_key=opt('--indexnow-key')), indent=1))
    elif cmd == 'verify': print(json.dumps(verify(a[1]), indent=1))
    elif cmd == 'indexnow': print(json.dumps(req('POST', 'forge/v1/indexnow', json={'urls': a[1:]}), indent=1))
    elif cmd == 'sitemap': [print(u) for u in sitemap_urls(opt('--base'))]
    elif cmd == 'links-check':
        r = links_check(json.load(open(a[1], encoding='utf-8')), opt('--base')); print(json.dumps(r, indent=1))
        if any(not x['live'] for x in r): die('one or more internal links are not live — remove or fix them before deploy', 2)
    elif cmd == 'bridge-zip': print('wrote', bridge_zip(a[1] if len(a) > 1 else 'forge-bridge.php'))
    else: die('unknown command ' + cmd)

if __name__ == '__main__':
    try: main(sys.argv[1:])
    except RuntimeError as e: die(str(e))
```

### forge/sample_blueprint.json

```json
{
 "forge": "1",
 "site": {
  "url": "https://www.example-firm.com",
  "name": "Example Employment Law",
  "brand": {
   "name": "Example Employment Law",
   "primary": "#1d4e89",
   "accent": "#c9a227",
   "dark": "#111110",
   "font_heading": "Georgia, serif",
   "font_body": "Inter, system-ui, sans-serif",
   "logo_url": "https://www.example-firm.com/wp-content/uploads/logo.png"
  }
 },
 "page": {
  "archetype": "location",
  "post_type": "page",
  "slug": "houston-wrongful-termination-lawyer",
  "title": "Houston Wrongful Termination Lawyer | Free Case Review",
  "h1": "Houston Wrongful Termination Lawyer",
  "meta_description": "Fired in Houston for an illegal reason? Employee-side lawyers review terminations free: discrimination, retaliation, FMLA, WARN. No fee unless we recover.",
  "language": "en-US",
  "template": "default",
  "breadcrumbs": [
   {
    "name": "Home",
    "url": "/"
   },
   {
    "name": "Practice Areas",
    "url": "/practice-areas/"
   }
  ],
  "summary": "Employee-side wrongful termination lawyers serving Houston and Harris County; free case review, no fee unless we recover.",
  "entity": {
   "@type": "LegalService",
   "name": "Example Employment Law",
   "telephone": "+1-713-555-0100",
   "address": {
    "@type": "PostalAddress",
    "streetAddress": "1000 Main St Suite 2300",
    "addressLocality": "Houston",
    "addressRegion": "TX",
    "postalCode": "77002",
    "addressCountry": "US"
   },
   "areaServed": [
    "Houston",
    "Harris County",
    "Fort Bend County",
    "Montgomery County"
   ],
   "priceRange": "Free consultation",
   "sameAs": [
    "https://www.linkedin.com/company/example-employment-law"
   ]
  },
  "service": {
   "@type": "Service",
   "serviceType": "Wrongful termination representation",
   "areaServed": "Houston, TX"
  },
  "author": {
   "name": "Jane Doe",
   "credentials": "Attorney, Texas Bar No. 00000000",
   "url": "https://www.example-firm.com/attorneys/jane-doe/",
   "bio": "Fifteen years representing employees in wrongful termination, retaliation and wage claims in Harris County courts and before the EEOC.",
   "media": "jane"
  },
  "dates": {
   "published": "2026-09-15",
   "modified": "2026-09-15"
  },
  "cta": {
   "primary": {
    "label": "Free Case Review",
    "url": "#contact",
    "phone": "(713) 555-0100",
    "phone_label": "Call (713) 555-0100"
   },
   "secondary": {
    "label": "How it works",
    "url": "#how-it-works"
   }
  },
  "conversion": {
   "sticky_mobile_bar": true,
   "trust": [
    "Free, confidential review",
    "No fee unless we recover",
    "Employees only — never employers"
   ],
   "form": {
    "provider": "html",
    "email_to": "intake@example-firm.com",
    "button": "Send my request"
   }
  },
  "internal_links": [
   {
    "anchor": "Retaliation lawyers in Houston",
    "url": "/houston-retaliation-lawyer/"
   },
   {
    "anchor": "Severance agreement review",
    "url": "/severance-review/"
   }
  ],
  "schema_extra": []
 },
 "media": {
  "hero": {
   "source": "assets/houston-skyline.jpg",
   "alt": "Downtown Houston skyline, home to Harris County courts",
   "kind": "image",
   "priority": true
  },
  "explainer": {
   "source": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
   "alt": "What counts as wrongful termination in Texas — 2 minute explainer",
   "kind": "video"
  },
  "poster": {
   "source": "assets/explainer-poster.jpg",
   "alt": "Attorney explaining wrongful termination",
   "kind": "image"
  },
  "jane": {
   "source": "library:jane doe headshot",
   "alt": "Attorney Jane Doe",
   "kind": "image"
  }
 },
 "sections": [
  {
   "type": "hero",
   "eyebrow": "Employee-side employment lawyers",
   "lede": "Texas is an at-will state, but discrimination, retaliation, protected leave and public-policy firings are still illegal. Tell us what happened; a lawyer reads it, free.",
   "media": "hero",
   "layout": "split",
   "cta": [
    "primary"
   ],
   "trust": true
  },
  {
   "type": "answer",
   "heading": "Can I sue for wrongful termination in Texas?",
   "body": "Yes, when the firing broke a specific law: discrimination under Title VII or the Texas Labor Code, retaliation for a protected complaint, interference with FMLA leave, a WARN Act layoff without notice, or a firing for refusing to commit an illegal act (Sabine Pilot). Most claims must be filed with the EEOC or TWC within 180 to 300 days."
  },
  {
   "type": "key_facts",
   "heading": "Harris County by the numbers",
   "items": [
    {
     "value": "180 days",
     "label": "TWC filing deadline for discrimination claims",
     "source": "Tex. Lab. Code § 21.202"
    },
    {
     "value": "300 days",
     "label": "EEOC deadline in Texas (dual-filing state)",
     "source": "42 U.S.C. § 2000e-5"
    },
    {
     "value": "2.4M",
     "label": "Private-sector workers in Harris County",
     "source": "QCEW Q1 2026"
    },
    {
     "value": "60 days",
     "label": "WARN Act notice owed in mass layoffs",
     "source": "29 U.S.C. § 2102"
    }
   ]
  },
  {
   "type": "rich_text",
   "heading": "What makes a firing illegal in Houston",
   "html": "<p>Texas employers may fire for a good reason, a bad reason or no reason — but never for an <strong>illegal</strong> reason. The claims we see most in Harris County courts and before the EEOC's Houston office:</p><ul><li><strong>Discrimination</strong> — age (40+), disability, pregnancy, race, sex, religion or national origin.</li><li><strong>Retaliation</strong> — fired after a harassment complaint, a wage complaint, a safety report or a workers' compensation claim.</li><li><strong>Leave interference</strong> — terminated during or right after FMLA or military leave.</li><li><strong>Mass layoffs without notice</strong> — the federal WARN Act's 60-day rule.</li><li><strong>Refusing to break the law</strong> — Texas's Sabine Pilot exception.</li></ul>"
  },
  {
   "type": "steps",
   "id": "how-it-works",
   "heading": "How a free case review works",
   "howto": false,
   "steps": [
    {
     "title": "Tell us what happened",
     "text": "Two minutes on the form or a call. Dates, the reason you were given and any documents you kept."
    },
    {
     "title": "A lawyer reads it",
     "text": "Not a call centre. Within one business day you hear whether there is a claim and what it is worth."
    },
    {
     "title": "We handle the deadline",
     "text": "If we take the case, we file with the TWC or EEOC and preserve every deadline while we build it."
    }
   ]
  },
  {
   "type": "video",
   "media": "explainer",
   "poster": "poster",
   "heading": "Two minutes on Texas wrongful termination",
   "transcript": "Texas is at-will, which means an employer does not need a reason to fire you. What it cannot do is fire you for an illegal reason..."
  },
  {
   "type": "testimonials",
   "heading": "What Houston clients say",
   "items": [
    {
     "quote": "They read my file the same day and told me exactly what my case was worth. The settlement was more than I expected.",
     "name": "M. R.",
     "role": "Retaliation claim, 2025",
     "rating": 5
    },
    {
     "quote": "Honest about the odds, relentless on the deadline. I would not have known about the 180-day rule.",
     "name": "D. K.",
     "role": "Age discrimination, 2026",
     "rating": 5
    }
   ]
  },
  {
   "type": "faq",
   "heading": "Wrongful termination questions Houston workers ask",
   "items": [
    {
     "q": "How long do I have to file a wrongful termination claim in Texas?",
     "a": "180 days with the Texas Workforce Commission for discrimination and retaliation under state law, 300 days with the EEOC under federal law. Other claims carry their own limits, so treat the day you were fired as day one."
    },
    {
     "q": "Does at-will employment mean I cannot sue?",
     "a": "No. At-will means no reason is required, not that any reason is allowed. Discrimination, retaliation and leave interference remain illegal in Texas."
    },
    {
     "q": "What is a wrongful termination case worth?",
     "a": "Back pay, front pay, emotional distress damages capped by employer size under federal law, and attorney's fees. Recent Harris County outcomes range from five-figure settlements to six-figure verdicts; every case turns on its facts."
    },
    {
     "q": "Do I pay anything up front?",
     "a": "No. The review is free and we work on contingency: no fee unless we recover for you. Court costs are discussed in writing before any case is filed."
    }
   ]
  },
  {
   "type": "authors",
   "heading": "Reviewed by"
  },
  {
   "type": "cta_band",
   "heading": "Fired in Houston? Find out today whether you have a case.",
   "text": "Free, confidential, read by a lawyer within one business day.",
   "cta": [
    "primary"
   ]
  },
  {
   "type": "form",
   "id": "contact",
   "heading": "Start your free case review",
   "text": "Tell us what happened. A lawyer, not a call centre, reads every submission."
  },
  {
   "type": "links",
   "heading": "Related",
   "items": [
    {
     "anchor": "Retaliation lawyers in Houston",
     "url": "/houston-retaliation-lawyer/"
    },
    {
     "anchor": "Severance agreement review",
     "url": "/severance-review/"
    }
   ]
  }
 ]
}
```
